"""
hot_stock 技能注册模块
用于将技能注册到OpenClaw系统中
"""

# 技能信息
SKILL_INFO = {
    "name": "hot_stock",
    "display_name": "热门股票分析",
    "description": "获取雪球、同花顺、东方财富等平台的热门股票排行榜，提供多维度的市场热点分析",
    "version": "1.0.0",
    "author": "OpenClaw Assistant",
    "functions": [
        {
            "name": "get_hot_stocks_with_common_analysis",
            "description": "获取热门股票并进行共同关注分析",
            "callable": True
        },
        {
            "name": "get_em_ranks",
            "description": "获取东方财富个股排行榜",
            "callable": True
        },
        {
            "name": "get_xueqiu_ranks",
            "description": "获取雪球各类榜单数据",
            "callable": True
        },
        {
            "name": "get_ths_ranks",
            "description": "获取同花顺问财数据",
            "callable": True
        },
        {
            "name": "get_hot_stocks_summary",
            "description": "获取热门股票综合概览",
            "callable": True
        },
        {
            "name": "get_common_stocks",
            "description": "获取跨平台共同关注的股票",
            "callable": True
        }
    ],
    "api_endpoints": [
        "/api/v1/stock/a/hot",
        "/api/v1/stock/a/xueqiu/ranks", 
        "/api/v1/stock/a/ths/ranks",
        "/api/v1/stock/a/em/ranks",
        "/api/v1/stock/a/hot/common",
        "/api/v1/stock/a/hot/summary"
    ],
    "requirements": [
        "akshare",
        "pywencai",
        "pandas",
        "requests",
        "fastapi",
        "uvicorn"
    ],
    "config_required": {
        "XUEQIU_TOKEN": "雪球Token，用于访问雪球API"
    }
}

def register_skill():
    """注册技能到系统"""
    print(f"注册技能: {SKILL_INFO['name']}")
    print(f"描述: {SKILL_INFO['description']}")
    return SKILL_INFO

if __name__ == "__main__":
    register_skill()