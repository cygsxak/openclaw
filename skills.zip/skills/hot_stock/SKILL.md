# 热门股票分析技能 (Hot Stock Analysis Skill)

## 描述
获取雪球、同花顺、东方财富等平台的热门股票排行榜，提供多维度的市场热点分析。

## 功能特性
- 东方财富个股排行榜（人气榜、涨幅榜、跌幅榜、成交量榜、换手率榜）
- 雪球各类榜单数据（热股、飙升、热评、自选、组合）
- 同花顺问财数据查询
- 多平台数据综合概览
- 跨平台共同关注股票分析
- FastAPI Web API服务

## 配置要求
雪球功能需要Token：XUEQIU_TOKEN
获取方式：登录雪球网站，从浏览器开发者工具的Cookie中获取xq_a_token值

## 工具函数

### get_em_ranks(type: str = "hot")
获取东方财富个股排行榜
- type: 榜单类型 - "hot"(人气榜), "soar"(涨幅榜), "drop"(跌幅榜), "vol"(成交量), "turnover"(换手率)

### get_xueqiu_ranks(type: str)
获取雪球各类榜单数据
- type: 榜单类型 - "hot"(热股), "soar"(飙升), "tweet"(热评), "follow"(自选), "cube"(组合)

### get_ths_ranks(query: str = "个股人气榜前100名")
获取同花顺问财数据
- query: 问财查询语句，默认查询热门个股

### get_hot_stocks_summary(platform: str = "all", type: str = "hot")
获取热门股票综合概览
- platform: 平台选择 - "em"(东方财富), "xueqiu"(雪球), "ths"(同花顺), "all"(全部)
- type: 榜单类型 - "hot"(人气榜), "soar"(涨幅榜), "drop"(跌幅榜), "vol"(成交量), "turnover"(换手率)

### get_common_stocks(hot_stocks_list: List[Dict[str, Any]])
获取跨平台共同关注的股票
- hot_stocks_list: 股票列表，统计每只股票出现在多少个平台

### get_hot_stocks_with_common_analysis(limit: int = 5)
获取热门股票并进行共同关注分析
- limit: 返回共同关注股票的数量限制

## API 端点

### FastAPI Web服务
该技能包含一个完整的FastAPI应用程序，可通过以下端点访问：

#### 启动API服务
```bash
cd skills/hot_stock
python run_api.py
```
服务将在 http://0.0.0.0:8000 上运行

#### API端点列表
- `GET /api/v1/stock/a/hot?limit=N` - 获取热门股票信号及跨平台分析
- `GET /api/v1/stock/a/xueqiu/ranks?type=T` - 获取雪球排行榜数据
- `GET /api/v1/stock/a/ths/ranks?query=Q` - 获取同花顺问财数据
- `GET /api/v1/stock/a/em/ranks?type=T` - 获取东方财富排行榜数据
- `GET /api/v1/stock/a/hot/common?limit=N` - 获取跨平台共同关注股票
- `GET /api/v1/stock/a/hot/summary?platform=P&type=T` - 获取热门股票综合概览
- `GET /docs` - 交互式API文档界面

## 使用示例

### 1. 直接函数调用
```python
from skills.hot_stock import get_hot_stocks_with_common_analysis

result = get_hot_stocks_with_common_analysis(limit=5)
print(f"共发现 {result['common_stocks_count']} 只跨平台共同关注股票")
```

### 2. API调用
```bash
# 获取热门股票及共同分析
curl "http://localhost:8000/api/v1/stock/a/hot?limit=5"

# 获取雪球热股榜
curl "http://localhost:8000/api/v1/stock/a/xueqiu/ranks?type=hot"

# 获取跨平台共同关注股票
curl "http://localhost:8000/api/v1/stock/a/hot/common?limit=10"
```