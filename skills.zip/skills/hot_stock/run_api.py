#!/usr/bin/env python3
"""
启动 Hot Stock Analysis API 服务
"""

import os
import uvicorn
from app import app

if __name__ == "__main__":
    print("Starting Hot Stock Analysis API Server...")
    print("Available endpoints:")
    print("  - GET  /                           : API home page")
    print("  - GET  /api/v1/stock/a/hot         : Hot stock signals with cross-platform analysis")
    print("  - GET  /api/v1/stock/a/xueqiu/ranks : Xueqiu (Snowball) rankings")
    print("  - GET  /api/v1/stock/a/ths/ranks   : Tonghuashun (iFinView) rankings") 
    print("  - GET  /api/v1/stock/a/em/ranks    : East Money rankings")
    print("  - GET  /api/v1/stock/a/hot/common  : Common stocks across platforms")
    print("  - GET  /docs                       : Interactive API documentation")
    print("\nEnvironment variables needed:")
    print(f"  - XUEQIU_TOKEN: {os.getenv('XUEQIU_TOKEN', 'Not set')}")
    print("\nServer will be available at: http://0.0.0.0:8000")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)