"""
热门股票分析技能主模块
提供雪球、同花顺、东方财富热股排行榜功能
"""

import os
import json
import pandas as pd
import requests
import time
from datetime import datetime
from typing import Dict, List, Any, Optional

def get_xueqiu_token():
    """获取雪球Token配置"""
    return os.getenv('XUEQIU_TOKEN', '')

def get_em_ranks(type: str = "hot") -> Dict[str, Any]:
    """
    获取东方财富个股排行榜
    类型: hot(人气榜), soar(涨幅榜), drop(跌幅榜), vol(成交量), turnover(换手率)
    """
    try:
        import akshare as ak
        
        items = []
        if type == "hot":
            df = ak.stock_hot_rank_em()
            if df is not None and not df.empty:
                rename_map = {
                    '代码': 'symbol',
                    '股票名称': 'name', 
                    '最新价': 'price',
                    '涨跌幅': 'change_percent',
                    '排名': 'rank',
                    '个股热度': 'score',
                    '新晋粉丝': 'new_fans',
                    '铁粉': 'loyal_fans'
                }
                final_rename = {k: v for k, v in rename_map.items() if k in df.columns}
                df = df.rename(columns=final_rename)
                if 'symbol' in df.columns:
                    df['symbol'] = df['symbol'].astype(str)
                df = df.where(pd.notnull(df), None)
                items = json.loads(df.to_json(orient='records', force_ascii=False))
        else:
            df = ak.stock_zh_a_spot_em()
            if df is not None and not df.empty:
                numeric_cols = ['最新价', '涨跌幅', '成交量', '成交额', '换手率']
                for col in numeric_cols:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                df = df.dropna(subset=['代码'])
                if type == "soar":
                    df = df.sort_values(by="涨跌幅", ascending=False)
                elif type == "drop":
                    df = df.sort_values(by="涨跌幅", ascending=True)
                elif type == "vol":
                    df = df.sort_values(by="成交额", ascending=False)
                elif type == "turnover":
                    df = df.sort_values(by="换手率", ascending=False)
                df = df.head(100)
                rename_map = {
                    '代码': 'symbol',
                    '名称': 'name',
                    '最新价': 'price', 
                    '涨跌幅': 'change_percent',
                    '成交额': 'amount',
                    '换手率': 'turnover_rate',
                    '涨跌额': 'change_amount',
                    '成交量': 'volume',
                    '最高': 'high',
                    '最低': 'low',
                    '今开': 'open',
                    '昨收': 'prev_close',
                    '市盈率-动态': 'pe_ttm',
                    '市净率': 'pb'
                }
                final_rename = {k: v for k, v in rename_map.items() if k in df.columns}
                df = df.rename(columns=final_rename)
                if 'symbol' in df.columns:
                    df['symbol'] = df['symbol'].astype(str)
                df = df.where(pd.notnull(df), None)
                items = json.loads(df.to_json(orient='records', force_ascii=False))

        return {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": type,
            "count": len(items),
            "data": items
        }
    except Exception as e:
        return {"error": str(e), "trace": str(e)}


def get_xueqiu_ranks(type: str) -> Dict[str, Any]:
    """
    获取雪球各类榜单数据
    类型: hot(热股), soar(飙升), tweet(热评), follow(自选), cube(组合)
    """
    try:
        xueqiu_token = get_xueqiu_token()
        if not xueqiu_token:
            return {"error": "缺少雪球Token，请配置XUEQIU_TOKEN环境变量"}
        
        headers = {
            'origin': 'https://xueqiu.com',
            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36',
            'cookie': f'xq_a_token={xueqiu_token};'
        }
        
        url = ""
        params = {
            "page": "1",
            "size": "100",
            "order": "desc",
            "_": str(int(time.time() * 1000)),
            "x": "0.5"
        }
        
        if type == "hot":  # 热股
            url = "https://stock.xueqiu.com/v5/stock/hot_stock/list.json"
            params.update({"order_by": "value", "type": "10"})
        elif type == "soar":  # 飙升
            url = "https://stock.xueqiu.com/v5/stock/hot_stock/new_list.json"
            params.update({"order_by": "rank_change", "type": "10"})
        elif type == "tweet":  # 热评
            url = "https://stock.xueqiu.com/v5/stock/hot_stock/list.json"
            params.update({"order_by": "value", "type": "30"})
        elif type == "follow":  # 自选
            url = "https://stock.xueqiu.com/v5/stock/hot_stock/list.json"
            params.update({"order_by": "value", "type": "40"})
        elif type == "cube":  # 组合
            url = "https://xueqiu.com/cube/center/cube_found/hot_symbol_list.json"
            params = {"page": "1", "size": "100"}
        else:
            return {"error": "不支持的榜单类型"}
        
        resp = requests.get(url, params=params, headers=headers, timeout=8)
        if resp.status_code == 200:
            data = resp.json()
            items = []
            
            if type == "cube":
                raw_items = data.get('list', []) or []
                for item in raw_items:
                    items.append({
                        "name": item.get('name'),
                        "symbol": item.get('symbol'),
                        "gain": item.get('daily_gain')
                    })
            else:
                raw_items = data.get('data', {}).get('items', []) or []
                for item in raw_items:
                    items.append({
                        "name": item.get('name'),
                        "symbol": item.get('symbol'),
                        "price": item.get('current'),
                        "change_percent": item.get('percent'),
                        "increment": item.get('increment')
                    })
            
            return {
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "type": type,
                "count": len(items),
                "data": items,
                "raw": data
            }
        else:
            return {"error": f"API请求失败: {resp.status_code}", "text": resp.text}
    except Exception as e:
        return {"error": str(e)}


def get_ths_ranks(query: str = "个股人气榜前100名") -> Dict[str, Any]:
    """
    获取同花顺问财数据
    默认查询热门个股
    """
    try:
        import pywencai
        
        os.environ['NODE_OPTIONS'] = '--no-warnings'
        res = pywencai.get(question=query, loop=True)
        if res is None:
            return {"error": "获取数据失败", "query": query}
        
        items = []
        if isinstance(res, dict):
            items = [res]
        elif isinstance(res, pd.DataFrame):
            if res.empty:
                return {"items": [], "count": 0, "query": query}
            
            rename_map = {
                '股票代码': 'symbol',
                'code': 'code',
                '股票简称': 'name',
                '最新价': 'price',
                '最新涨跌幅': 'change_percent',
                '涨跌幅': 'change_percent',
                'market_code': 'market'
            }
            
            # 查找热度排名和分数列
            rank_col = next((c for c in res.columns if '热度排名' in c or '人气榜' in c), None)
            score_col = next((c for c in res.columns if '热度' in c and '排名' not in c), None)
            
            if rank_col:
                rename_map[rank_col] = 'rank'
            if score_col:
                rename_map[score_col] = 'score'
            
            final_rename_map = {k: v for k, v in rename_map.items() if k in res.columns}
            df_renamed = res.rename(columns=final_rename_map)
            df_renamed = df_renamed.where(pd.notnull(df_renamed), None)
            items = df_renamed.to_dict(orient='records')
        else:
            return {"error": f"未知返回类型: {type(res)}", "query": query}
        
        return {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "query": query,
            "count": len(items),
            "data": items
        }
    except ImportError:
        return {"error": "pywencai库未安装，请安装后使用此功能"}
    except Exception as e:
        return {"error": str(e), "trace": str(e)}


def get_hot_stocks_summary(platform: str = "all", type: str = "hot") -> Dict[str, Any]:
    """
    获取热门股票综合概览
    平台: em(东方财富), xueqiu(雪球), ths(同花顺), all(全部)
    类型: hot(人气榜), soar(涨幅榜), drop(跌幅榜), vol(成交量), turnover(换手率)
    """
    result = {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "platform": platform,
        "type": type,
        "data": {}
    }
    
    if platform in ["em", "all"]:
        em_data = get_em_ranks(type)
        result["data"]["eastmoney"] = em_data
    
    if platform in ["xueqiu", "all"]:
        xq_data = get_xueqiu_ranks(type)
        result["data"]["xueqiu"] = xq_data
    
    if platform in ["ths", "all"]:
        ths_data = get_ths_ranks()
        result["data"]["tonghuashun"] = ths_data
    
    return result


def normalize_stock_code(code: str) -> str:
    """
    标准化股票代码格式
    统一处理不同平台的股票代码格式差异
    例如: '002506.SZ' -> '002506', 'SZ002506' -> '002506'
    """
    if not code:
        return ''
    
    # 移除前后空格
    code = code.strip()
    
    # 移除市场后缀（.SZ, .SH, .BJ）
    if '.' in code:
        code = code.split('.')[0]
    
    # 移除市场前缀（SZ, SH, BJ）
    if code.startswith(('SZ', 'SH', 'BJ')):
        code = code[2:]
    
    # 确保是6位数字
    if len(code) == 6 and code.isdigit():
        return code
    else:
        return ''  # 无效代码


def get_common_stocks(hot_stocks_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    获取跨平台共同关注的股票
    """
    # 统计每只股票出现在多少个平台
    stock_counter = {}
    for stock in hot_stocks_list:
        original_code = stock.get('symbol', stock.get('code', ''))
        normalized_code = normalize_stock_code(original_code)
        
        if normalized_code:
            if normalized_code not in stock_counter:
                stock_counter[normalized_code] = {
                    'code': original_code,  # 保存原始代码用于显示
                    'normalized_code': normalized_code,
                    'name': stock.get('name', ''),
                    'price': stock.get('price', ''),
                    'change_percent': stock.get('change_percent', ''),
                    'sources': [],
                    'source_details': []
                }
            
            source = stock.get('source', 'unknown')
            # 检查是否已经记录了相同的来源
            source_exists = any(detail['source'] == source for detail in stock_counter[normalized_code]['source_details'])
            if not source_exists:
                if source not in stock_counter[normalized_code]['sources']:
                    stock_counter[normalized_code]['sources'].append(source)
                
                stock_counter[normalized_code]['source_details'].append({
                    'source': source,
                    'original_code': original_code,
                    'name': stock.get('name', ''),
                    'price': stock.get('price', ''),
                    'change_percent': stock.get('change_percent', '')
                })
    
    # 筛选出至少在两个平台出现的股票
    common_stocks = [details for details in stock_counter.values() if len(details['sources']) >= 2]
    
    # 按出现平台数量排序
    common_stocks.sort(key=lambda x: len(x['sources']), reverse=True)
    
    return common_stocks


def get_hot_stocks_with_common_analysis(limit: int = 5) -> Dict[str, Any]:
    """
    获取热门股票并进行共同关注分析
    """
    # 获取所有平台的热门股票
    all_data = get_hot_stocks_summary(platform='all', type='hot')
    
    # 整合所有股票数据
    all_stocks = []
    
    # 东方财富数据
    em_data = all_data['data'].get('eastmoney', {})
    if 'data' in em_data:
        for item in em_data['data']:
            stock_item = item.copy()  # 创建副本以避免修改原数据
            stock_item['source'] = '东方财富'
            # 确保股票代码格式正确
            if 'symbol' not in stock_item and 'code' not in stock_item:
                stock_item['symbol'] = item.get('symbol', item.get('code', ''))
            all_stocks.append(stock_item)
    
    # 雪球数据
    xq_data = all_data['data'].get('xueqiu', {})
    if 'data' in xq_data:
        for item in xq_data['data']:
            stock_item = item.copy()  # 创建副本以避免修改原数据
            stock_item['source'] = '雪球'
            # 确保股票代码格式正确
            if 'symbol' not in stock_item and 'code' not in stock_item:
                stock_item['symbol'] = item.get('symbol', item.get('code', ''))
            all_stocks.append(stock_item)
    
    # 同花顺数据
    ths_data = all_data['data'].get('tonghuashun', {})
    if 'data' in ths_data:
        for item in ths_data['data']:
            stock_item = item.copy()  # 创建副本以避免修改原数据
            stock_item['source'] = '同花顺'
            # 确保股票代码格式正确
            if 'symbol' not in stock_item and 'code' not in stock_item:
                stock_item['symbol'] = item.get('symbol', item.get('code', ''))
            all_stocks.append(stock_item)
    
    # 获取共同关注股票
    common_stocks = get_common_stocks(all_stocks)
    
    # 为了兼容性，移除标准化代码字段，只返回原始格式
    for stock in common_stocks:
        if 'normalized_code' in stock:
            del stock['normalized_code']
    
    return {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_hot_stocks": len(all_stocks),
        "common_stocks_count": len(common_stocks),
        "all_stocks": all_stocks,
        "common_stocks": common_stocks,
        "top_common": common_stocks[:limit] if common_stocks else []
    }