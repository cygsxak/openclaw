"""
热门股票分析技能配置文件
"""

import os

# 雪球Token配置
XUEQIU_TOKEN = os.getenv('XUEQIU_TOKEN', '')