# 股票分析技能 (XueQiu Stock Analysis Skill)

## 描述
A股股票深度分析，集成技术指标计算、AI决策分析、实时行情获取和新闻资讯摘要功能。

## 功能特性
- 实时股票行情获取（雪球数据源）
- 技术指标计算（MA5/MA20, MACD, RSI, ATR等）
- AI辅助投资决策
- 价格区间建议
- 风险评估与警示
- 热门股票排行分析
- 自选股实时行情查询
- 股票新闻资讯摘要

## 配置要求
需要雪球Token：XUEQIU_TOKEN
获取方式：登录雪球网站，从浏览器开发者工具的Cookie中获取xq_a_token值

## 工具函数

### analyze_stock(symbol: str)
分析单只股票的技术指标和AI决策

### get_hot_stocks()
获取雪球热门股票排行

### query_my_stocks(cookie: str)
查询雪球自选股实时行情

### get_xueqiu_portfolio(cookie: str)
获取雪球自选股列表

### get_stock_quotes(symbols: List[str], cookie: str)
获取指定股票的实时行情

### query_stock_news(symbol: str, cookie: str)
查询股票最新消息并进行摘要总结

### get_stock_news(symbol: str, cookie: str)
获取股票相关新闻列表

### get_social_media_sentiment(symbol: str, cookie: str)
获取股票在社交媒体（雪球社区、微博等）的讨论情绪分析

### summarize_news(news_list: List[Dict[str, Any]], stock_name: str = "")
对新闻列表进行摘要总结（200字以内）

### get_technical_indicators(df: pd.DataFrame)
计算技术指标（MA5/MA20, MACD, RSI, ATR等）

### get_ai_decision(intelligence: dict)
基于AI的投资决策分析

### suggest_price_range(current_price: float, atr: float, support: float, resistance: float)
根据ATR和支撑/压力位给出价格区间建议