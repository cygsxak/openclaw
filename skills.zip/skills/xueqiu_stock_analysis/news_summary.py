#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
雪球股票新闻摘要模块
"""

import os
import json
import pandas as pd
import requests
import re
import html
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import time


def get_stock_news(symbol: str, cookie: str) -> List[Dict[str, Any]]:
    """
    获取股票相关新闻
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Cookie': cookie
    }
    
    # 雪球新闻API
    news_url = 'https://xueqiu.com/statuses/search.json'
    news_params = {
        'q': symbol,
        'page': 1,
        'size': 20,
        'sort': 'score',
        '_': str(int(time.time() * 1000))
    }
    
    try:
        response = requests.get(news_url, headers=headers, params=news_params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            items = data.get('items', [])
            news_list = []
            
            for item in items:
                if item and 'text' in item:
                    # 提取标题和内容
                    text = item.get('text', '')
                    title = item.get('title', '')
                    created_at = item.get('created_at', '')
                    user = item.get('user', {}).get('screen_name', '未知用户')
                    
                    # 清理文本内容
                    clean_text = re.sub(r'<.*?>', '', text)  # 移除HTML标签
                    clean_text = html.unescape(clean_text)  # 处理HTML实体
                    
                    news_item = {
                        'title': title,
                        'content': clean_text,
                        'created_at': created_at,
                        'author': user,
                        'source': '雪球'
                    }
                    
                    news_list.append(news_item)
            
            return news_list
        else:
            print(f'获取新闻数据失败: {response.status_code}')
            return []
    except Exception as e:
        print(f'获取新闻数据异常: {str(e)}')
        return []


def summarize_news(news_list: List[Dict[str, Any]], stock_name: str = "") -> str:
    """
    对新闻列表进行摘要总结（200字以内）
    """
    if not news_list:
        return "未获取到相关新闻。"
    
    # 取最近的几条重要新闻
    recent_news = news_list[:5]
    
    # 组织新闻内容
    content_parts = []
    for news in recent_news:
        title = news.get('title', '')
        content = news.get('content', '')
        
        # 如果有标题就用标题，否则用内容的前100个字符
        if title:
            content_parts.append(title)
        elif content:
            content_parts.append(content[:100] + "..." if len(content) > 100 else content)
    
    # 合并新闻要点
    combined_content = "；".join(content_parts)
    
    # 生成摘要
    if len(combined_content) > 180:
        summary = combined_content[:177] + "..."
    else:
        summary = combined_content
    
    if stock_name:
        summary = f"{stock_name}相关资讯摘要：{summary}"
    else:
        summary = f"股票资讯摘要：{summary}"
    
    return summary


def query_stock_news(symbol: str, cookie: str) -> Dict[str, Any]:
    """
    查询股票最新消息并进行摘要总结
    """
    # 获取新闻数据
    news_list = get_stock_news(symbol, cookie)
    
    # 生成摘要
    if news_list:
        # 获取股票名称
        stock_name = ""
        try:
            # 尝试获取股票名称
            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Cookie': cookie
            }
            
            # 根据股票代码获取股票名称
            if symbol.startswith(('SH', 'SZ')):
                code = symbol[2:]
            else:
                code = symbol
            
            url = f'http://hq.sinajs.cn/list={symbol.lower() if symbol.startswith(("SH", "SZ")) else ("sh" if symbol.startswith(("5", "6", "9")) else "sz")}{code}'
            response = requests.get(url, headers=headers, timeout=5)
            if response.status_code == 200:
                text = response.content.decode('gbk', errors='ignore')
                if '=\"' in text:
                    data = text.split('\"')[1].split(',')
                    if data and len(data[0]) > 0:
                        stock_name = data[0]
        except Exception:
            pass
        
        summary = summarize_news(news_list, stock_name)
        
        return {
            "news_count": len(news_list),
            "summary": summary,
            "recent_news": news_list[:5],  # 返回最近5条新闻
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    else:
        return {
            "news_count": 0,
            "summary": f"未获取到关于{symbol}的相关新闻。",
            "recent_news": [],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }


if __name__ == "__main__":
    # 使用默认cookie值
    cookie = 's=ak16ifihe4; cookiesu=481770170902383; Hm_lvt_1db88642e346389874251b5a1eded6e3=1770170905; HMACCOUNT=926D01031F8F8510; device_id=67dc5b6be5358d3e2d38ada620f024d7; xq_a_token=0f49dbc43aabce03285668102b697d110abf0287; xqat=0f49dbc43aabce03285668102b697d110abf0287; xq_r_token=9fc624b8389d5c731ff388108023728b9a7fd6e7; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOjQ4MzUwMzY0NjIsImlzcyI6InVjIiwiZXhwIjoxNzcxOTM4Nzg3LCJjdG0iOjE3NzAxNzA5Njg1MTYsImNpZCI6ImQ5ZDBuNEFadXAifQ.d1JX1zqGxgyDu6hmcSqMgRlxtIYfEbReelmhGlzcSMblhuANPPqhMij1FiABwaaT4yDwVh4tj2Si1BJKuVYBM2LwgokiClu8nytC_x-Z9SAN7xF0e1enCyabRGRy7B6cAyYM9Gl3buFI8dQweu1fxuibgvlws0lNvuQ1r-P57Ii-f_HDr7Ur6_dh5yaXVa0SmWS58CDHXvAj4XC1mYhJSGV7k-I5O9-UuMEYaGfl8NptNR_78BGk0ctU3LioVqLOY3x3akOSjhENJNcJ3cpXZft1jH7jMerSmXTZS7IiEFfbr0CqnpCtQ05YEYX4wpgk_YnE1drKQjXJNM0FqGexCg; xq_is_login=1; u=4835036462; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1770170974; ssxmod_itna=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OiNDlELeDZDGIQDqx0EbRWWioiKS_lQwYoZRjAEAQP8U22hIQb0AEkyrbvO1kRfyG6MzfDXtAeDU4GnD0=m3ohbDYYjDBYD74G_DDeDixGm7eDSbxD9DGp=qpnbMeDEDYPaxitPOgaOxDLW9jROvDDBIb2d72u4DDX4dnxoN0xOxGYPv=pde1GAwY_=x0tFDBdKDXG=xtl2dYcAuzk7kfbDzdzDtLWzqZ_8lCaTh6mQYvDF4XmKD9e40KKCGqQeXiD4ehteA590xBG=0GPKoXehzi0bDDASriSh5=medhlfyZWPwn5mDA170D9iTBqCIToKDk9iqlGO3hqS2N4br4Rr/iozDKNG4Tbx1GDD; ssxmod_itna2=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OioDicwBKrpBmD03q7YR8Ie58DGXYFd7=452wp=Dkx0qWNKUBh7OwWj4LQRG=wBQSddjbDQOQR3O/4Lq_0=Ob7Lcmd4qNiRY9DL3NlGecCDrDM3O94NtblQVDwx=Exn3sYrrC0fqt_xqw7G8NiitNLjiHaKK3qn5cCjQ5iH9GCX4Hdc==jNPkTHRj8qtoa0INncM9008pTS670tqXSUV3KdL3RR6NR0vxy0cdpBLxPzHuTK08oSH8wKudHpEQtbW=nQn4Q88GVh=c_GZxaBO8Yh1Zu59_Tz8G_3hwOq0kQpgqYjNyfGRDWpMiuRFgfIoCtpohk0xGhvRgvQnQM4AIOz5DQzbt3=qwriFC1ZfC82Q4Lbki7jqtRdwzbv3pWWmIgqdIl84bExcFUxjXQHbSGN=rUu=OibUdHlor7jbVYatRQq0vSfDy21fQq4kGbTN7ezK03o98mQk5fQr61Ch7r7pHtqNqFSS6sms8lv2TvhuaqmTU8noWI/LUawvLTx56wa_657hKmrSzOPAiiQnaRTLqNz4Gj8NOLQ357TI7jxWhkQBFEcWiPG3NpHZDfoigY70gb0axdQB3vhx=uuC2qLsdM4/OUYkS_qYxVQ/Bpb7q5ECbN6_iU4EBN/NqmVfXQDZRj=iS7wUDYbqgk4d3yYZehM0fljig42dNj/tD5Ae3xXTPdhTn5D4s0rQ4/kqb28C3A2YiDD'
    
    import sys
    if len(sys.argv) < 2:
        print("请提供股票代码作为参数")
        exit(1)
    
    symbol = sys.argv[1]
    result = query_stock_news(symbol, cookie)
    
    print(f"股票代码: {symbol}")
    print(f"获取到 {result['news_count']} 条相关新闻")
    print(f"摘要: {result['summary']}")
    print("\n最近新闻:")
    for i, news in enumerate(result['recent_news'], 1):
        print(f"{i}. {news['title'] or news['content'][:50]}...")