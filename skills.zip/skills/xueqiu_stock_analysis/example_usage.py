"""
雪球股票分析技能示例使用代码
"""

from .api import (
    api_analyze_single_stock, 
    api_analyze_multiple_stocks, 
    api_get_hot_stocks,
    api_get_technical_indicators,
    api_get_ai_recommendation,
    api_compare_stocks
)

def example_single_stock_analysis():
    """
    示例：单只股票分析
    """
    print("=== 单只股票分析示例 ===")
    
    # 分析茅台股票
    result = api_analyze_single_stock("600519")
    
    if 'error' in result:
        print(f"错误: {result['error']}")
        return
    
    print(f"股票: {result['data']['name']}({result['data']['symbol']})")
    print(f"价格: ¥{result['data']['price']}")
    print(f"涨跌幅: {result['data']['change_percent']}%")
    print(f"AI建议: {result['decision']['action']}")
    print(f"建议仓位: {result['decision']['weight']}")
    print("\n详细报告:")
    print(result['formatted_report'])


def example_multiple_stocks_analysis():
    """
    示例：多只股票分析
    """
    print("\n=== 多只股票分析示例 ===")
    
    symbols = ["600519", "000858", "601318"]  # 茅台、五粮液、平安
    results = api_analyze_multiple_stocks(symbols)
    
    for result in results:
        if 'error' in result:
            print(f"错误: {result['error']}")
            continue
        
        print(f"{result['data']['name']}({result['data']['symbol']}): "
              f"¥{result['data']['price']} ({result['data']['change_percent']}%), "
              f"AI建议: {result['decision']['action']}")


def example_hot_stocks():
    """
    示例：获取热门股票
    """
    print("\n=== 热门股票示例 ===")
    
    result = api_get_hot_stocks()
    
    if 'error' in result.get('data', {}):
        print(f"错误: {result['data'][0]['error']}")
        print("注意: 需要配置XUEQIU_TOKEN才能获取热门股票数据")
        return
    
    hot_stocks = result['data'][:5]  # 只显示前5只
    
    print("热门股票:")
    for i, stock in enumerate(hot_stocks, 1):
        print(f"{i}. {stock.get('name', 'N/A')}({stock.get('symbol', 'N/A')}): "
              f"¥{stock.get('price', 'N/A')} ({stock.get('change_percent', 'N/A')}%)")


def example_technical_indicators():
    """
    示例：获取技术指标
    """
    print("\n=== 技术指标示例 ===")
    
    result = api_get_technical_indicators("600519")
    
    if 'error' in result:
        print(f"错误: {result['error']}")
        return
    
    techs = result['technicals']
    print(f"{result['name']}({result['symbol']}) 技术指标:")
    print(f"  趋势: {techs.get('trend', 'N/A')}")
    print(f"  MA5: {techs.get('MA5', 'N/A')}, MA20: {techs.get('MA20', 'N/A')}")
    print(f"  MACD(DIF): {techs.get('MACD_DIF', 'N/A')}")
    print(f"  MACD(DEA): {techs.get('MACD_DEA', 'N/A')}")
    print(f"  MACD(HIST): {techs.get('MACD_HIST', 'N/A')}")
    print(f"  RSI14: {techs.get('RSI14', 'N/A')}")
    print(f"  ATR14: {techs.get('ATR14', 'N/A')}")
    print(f"  支撑位: {techs.get('support', 'N/A')}")
    print(f"  压力位: {techs.get('resistance', 'N/A')}")


def example_ai_recommendation():
    """
    示例：获取AI投资建议
    """
    print("\n=== AI投资建议示例 ===")
    
    result = api_get_ai_recommendation("600519")
    
    if 'error' in result:
        print(f"错误: {result['error']}")
        return
    
    rec = result['recommendation']
    print(f"{result['name']}({result['symbol']}) AI投资建议:")
    print(f"  操作: {rec['action']}")
    print(f"  建议仓位: {rec['weight']}")
    print(f"  价格区间: {rec['price_range']}")
    print(f"  评分: {rec['scores']['total']}/100")
    print(f"  理由: {rec['reason'][:100]}...")


def example_stocks_comparison():
    """
    示例：股票比较
    """
    print("\n=== 股票比较示例 ===")
    
    symbols = ["600519", "000858", "000568"]  # 茅台、五粮液、泸州老窖
    result = api_compare_stocks(symbols)
    
    if 'error' in result:
        print(f"错误: {result['error']}")
        return
    
    print("股票比较结果:")
    for stock in result['stocks']:
        print(f"  {stock['name']}({stock['symbol']}): "
              f"¥{stock['price']}, {stock['change_percent']}%, "
              f"RSI:{stock['rsi']}, 趋势:{stock['trend']}, 建议:{stock['recommendation']}")
    
    print("\n汇总:")
    summary = result['summary']
    print(f"  RSI最高: {summary['highest_rsi']['symbol']} ({summary['highest_rsi']['value']})")
    print(f"  RSI最低: {summary['lowest_rsi']['symbol']} ({summary['lowest_rsi']['value']})")
    print(f"  涨幅最大: {summary['biggest_gainer']['symbol']} ({summary['biggest_gainer']['change']}%)")
    print(f"  跌幅最大: {summary['biggest_loser']['symbol']} ({summary['biggest_loser']['change']}%)")


def run_all_examples():
    """
    运行所有示例
    """
    print("开始运行雪球股票分析技能示例...")
    
    try:
        example_single_stock_analysis()
        example_multiple_stocks_analysis()
        example_hot_stocks()
        example_technical_indicators()
        example_ai_recommendation()
        example_stocks_comparison()
        
        print("\n所有示例运行完成!")
        
    except Exception as e:
        print(f"运行示例时出现错误: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    run_all_examples()