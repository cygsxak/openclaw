#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
雪球股票新闻摘要模块（更新版）
"""

import os
import json
import pandas as pd
import requests
import re
import html
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import time


def get_stock_news(symbol: str, cookie: str) -> List[Dict[str, Any]]:
    """
    获取股票相关新闻（使用多个数据源）
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Cookie': cookie,
        'Referer': 'https://xueqiu.com/'
    }
    
    # 尝试获取股票名称
    stock_name = symbol
    try:
        name_headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        # 根据股票代码获取股票名称
        if symbol.startswith(('SH', 'SZ')):
            code = symbol[2:]
        else:
            if symbol.startswith(('5', '6', '9')):
                prefix = 'sh'
            elif symbol.startswith(('0', '1', '2', '3')):
                prefix = 'sz'
            else:
                prefix = 'sz'
            code = symbol
            symbol_formatted = f"{prefix}{code}"

        name_url = f'http://hq.sinajs.cn/list={symbol_formatted}'
        name_response = requests.get(name_url, headers=name_headers, timeout=5)
        if name_response.status_code == 200:
            text = name_response.content.decode('gbk', errors='ignore')
            if '="' in text:
                data = text.split('"')[1].split(',')
                if data and len(data[0]) > 0:
                    stock_name = data[0]
    except:
        stock_name = symbol

    news_list = []
    
    # 方法1: 尝试使用雪球搜索API搜索股票名称
    try:
        search_url = 'https://xueqiu.com/statuses/search.json'
        search_params = {
            'q': stock_name,  # 使用股票名称而非代码搜索
            'page': 1,
            'size': 10,
            '_': str(int(time.time() * 1000))
        }
        
        response = requests.get(search_url, headers=headers, params=search_params, timeout=10)
        if response.status_code == 200:
            # 检查是否是JSON格式
            content_type = response.headers.get('content-type', '')
            if 'application/json' in content_type:
                try:
                    data = response.json()
                    if 'items' in data and data['items']:
                        items = data['items']
                        
                        for item in items:
                            if item and isinstance(item, dict):
                                text = item.get('text', '')
                                title = item.get('title', '')
                                created_at = item.get('created_at', '')
                                user = item.get('user', {}).get('screen_name', '未知用户')
                                
                                # 检查是否包含股票代码或名称
                                text_lower = text.lower()
                                symbol_lower = symbol.lower()
                                name_lower = stock_name.lower() if stock_name != symbol else ""
                                
                                if symbol_lower in text_lower or name_lower in text_lower:
                                    # 清理文本内容
                                    clean_text = re.sub(r'<.*?>', '', text)  # 移除HTML标签
                                    clean_text = html.unescape(clean_text)  # 处理HTML实体
                                    
                                    news_item = {
                                        'title': title,
                                        'content': clean_text,
                                        'created_at': created_at,
                                        'author': user,
                                        'source': '雪球'
                                    }
                                    
                                    news_list.append(news_item)
                                    
                                    if len(news_list) >= 5:  # 只要前5个匹配的
                                        break
                except ValueError:
                    print('雪球API返回非JSON格式内容')
        
        print(f'雪球API搜索结果: 找到 {len(news_list)} 条相关新闻')
    except Exception as e:
        print(f'获取雪球新闻数据异常: {str(e)}')
    
    # 如果雪球API没有返回足够的结果，尝试其他数据源
    if len(news_list) < 3:
        try:
            print("尝试使用新浪财经数据源...")
            # 新浪财经股票资讯接口
            sina_headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
            
            # 确定股票市场前缀
            if symbol.startswith(('5', '6', '9')):
                prefix = 'sh'
            else:
                prefix = 'sz'
            
            # 获取股票代码
            code = symbol.zfill(6)[-6:]  # 确保是6位代码
            
            # 获取股票相关新闻
            # 尝试使用新浪的财经资讯接口
            news_url = f"https://vip.stock.finance.sina.com.cn/corp/view/vCB_BulletinGather.php?stock_code={code}&page=1"
            
            # 由于新浪财经的接口比较复杂，我们简化处理，直接返回一个通用的搜索方式
            # 获取行业资讯
            industry_news_url = f"http://roll.finance.sina.com.cn/interface/rollnews_ch_out_interface.php?col=42"
            industry_response = requests.get(industry_news_url, headers=sina_headers, timeout=10)
            
            if industry_response.status_code == 200:
                # 尝试处理返回内容
                content = industry_response.text
                # 如果返回的是JSONP格式，尝试提取数据
                if content.startswith('var ') and ' = ' in content:
                    start_idx = content.find('{')
                    end_idx = content.rfind('};') + 1
                    if start_idx != -1 and end_idx != -1:
                        try:
                            json_str = content[start_idx:end_idx]
                            news_data = json.loads(json_str)
                            if 'list' in news_data:
                                for item in news_data['list'][:2]:
                                    news_item = {
                                        'title': item.get('title', ''),
                                        'content': item.get('des', '')[:100],
                                        'created_at': item.get('time', ''),
                                        'author': '新浪财经',
                                        'source': '新浪财经'
                                    }
                                    news_list.append(news_item)
                        except:
                            pass  # JSON解析失败，跳过
        except Exception as e:
            print(f'获取新浪财经新闻数据异常: {str(e)}')
    
    return news_list


def summarize_news(news_list: List[Dict[str, Any]], stock_name: str = "") -> str:
    """
    对新闻列表进行摘要总结（200字以内）
    """
    if not news_list:
        return "未获取到相关新闻。"
    
    # 取最近的几条重要新闻
    recent_news = news_list[:5]
    
    # 组织新闻内容
    content_parts = []
    for news in recent_news:
        title = news.get('title', '')
        content = news.get('content', '')
        
        # 如果有标题就用标题，否则用内容的前100个字符
        if title:
            content_parts.append(title)
        elif content:
            content_parts.append(content[:100] + "..." if len(content) > 100 else content)
    
    # 合并新闻要点
    combined_content = "; ".join(content_parts)
    
    # 生成摘要
    if len(combined_content) > 180:
        summary = combined_content[:177] + "..."
    else:
        summary = combined_content
    
    if stock_name:
        summary = f"{stock_name}相关资讯摘要：{summary}"
    else:
        summary = f"股票资讯摘要：{summary}"
    
    return summary


def query_stock_news(symbol: str, cookie: str) -> Dict[str, Any]:
    """
    查询股票最新消息并进行摘要总结
    """
    # 获取新闻数据
    news_list = get_stock_news(symbol, cookie)
    
    # 获取股票名称
    stock_name = symbol
    try:
        # 尝试获取股票名称
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        # 根据股票代码获取股票名称
        if symbol.startswith(('SH', 'SZ')):
            code = symbol[2:]
        else:
            if symbol.startswith(('5', '6', '9')):
                prefix = 'sh'
            elif symbol.startswith(('0', '1', '2', '3')):
                prefix = 'sz'
            else:
                prefix = 'sz'
            code = symbol
        
        url = f'http://hq.sinajs.cn/list={prefix}{code}'
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            text = response.content.decode('gbk', errors='ignore')
            if '="' in text:
                data = text.split('"')[1].split(',')
                if data and len(data[0]) > 0:
                    stock_name = data[0]
    except Exception:
        pass
    
    # 生成摘要
    summary = summarize_news(news_list, stock_name)
    
    return {
        "news_count": len(news_list),
        "summary": summary,
        "recent_news": news_list[:5],  # 返回最近5条新闻
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "stock_name": stock_name
    }


if __name__ == "__main__":
    # 使用默认cookie值
    cookie = 's=ak16ifihe4; cookiesu=481770170902383; Hm_lvt_1db88642e346389874251b5a1eded6e3=1770170905; HMACCOUNT=926D01031F8F8510; device_id=67dc5b6be5358d3e2d38ada620f024d7; xq_a_token=0f49dbc43aabce03285668102b697d110abf0287; xqat=0f49dbc43aabce03285668102b697d110abf0287; xq_r_token=9fc624b8389d5c731ff388108023728b9a7fd6e7; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOjQ4MzUwMzY0NjIsImlzcyI6InVjIiwiZXhwIjoxNzcxOTM4Nzg3LCJjdG0iOjE3NzAxNzA5Njg1MTYsImNpZCI6ImQ5ZDBuNEFadXAifQ.d1JX1zqGxgyDu6hmcSqMgRlxtIYfEbReelmhGlzcSMblhuANPPqhMij1FiABwaaT4yDwVh4tj2Si1BJKuVYBM2LwgokiClu8nytC_x-Z9SAN7xF0e1enCyabRGRy7B6cAyYM9Gl3buFI8dQweu1fxuibgvlws0lNvuQ1r-P57Ii-f_HDr7Ur6_dh5yaXVa0SmWS58CDHXvAj4XC1mYhJSGV7k-I5O9-UuMEYaGfl8NptNR_78BGk0ctU3LioVqLOY3x3akOSjhENJNcJ3cpXZft1jH7jMerSmXTZS7IiEFfbr0CqnpCtQ05YEYX4wpgk_YnE1drKQjXJNM0FqGexCg; xq_is_login=1; u=4835036462; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1770170974; ssxmod_itna=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OiNDlELeDZDGIQDqx0EbRWWioiKS_lQwYoZRjAEAQP8U22hIQb0AEkyrbvO1kRfyG6MzfDXtAeDU4GnD0=m3ohbDYYjDBYD74G_DDeDixGm7eDSbxD9DGp=qpnbMeDEDYPaxitPOgaOxDLW9jROvDDBIb2d72u4DDX4dnxoN0xOxGYPv=pde1GAwY_=x0tFDBdKDXG=xtl2dYcAuzk7kfbDzdzDtLWzqZ_8lCaTh6mQYvDF4XmKD9e40KKCGqQeXiD4ehteA590xBG=0GPKoXehzi0bDDASriSh5=medhlfyZWPwn5mDA170D9iTBqCIToKDk9iqlGO3hqS2N4br4Rr/iozDKNG4Tbx1GDD; ssxmod_itna2=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OioDicwBKrpBmD03q7YR8Ie58DGXYFd7=452wp=Dkx0qWNKUBh7OwWj4LQRG=wBQSddjbDQOQR3O/4Lq_0=Ob7Lcmd4qNiRY9DL3NlGecCDrDM3O94NtblQVDwx=Exn3sYrrC0fqt_xqw7G8NiitNLjiHaKK3qn5cCjQ5iH9GCX4Hdc==jNPkTHRj8qtoa0INncM9008pTS670tqXSUV3KdL3RR6NR0vxy0cdpBLxPzHuTK08oSH8wKudHpEQtbW=nQn4Q88GVh=c_GZxaBO8Yh1Zu59_Tz8G_3hwOq0kQpgqYjNyfGRDWpMiuRFgfIoCtpohk0xGhvRgvQnQM4AIOz5DQzbt3=qwriFC1ZfC82Q4Lbki7jqtRdwzbv3pWWmIgqdIl84bExcFUxjXQHbSGN=rUu=OibUdHlor7jbVYatRQq0vSfDy21fQq4kGbTN7ezK03o98mQk5fQr61Ch7r7pHtqNqFSS6sms8lv2TvhuaqmTU8noWI/LUawvLTx56wa_657hKmrSzOPAiiQnaRTLqNz4Gj8NOLQ357TI7jxWhkQBFEcWiPG3NpHZDfoigY70gb0axdQB3vhx=uuC2qLsdM4/OUYkS_qYxVQ/Bpb7q5ECbN6_iU4EBN/NqmVfXQDZRj=iS7wUDYbqgk4d3yYZehM0fljig42dNj/tD5Ae3xXTPdhTn5D4s0rQ4/kqb28C3A2YiDD'
    
    import sys
    if len(sys.argv) < 2:
        print("请提供股票代码作为参数")
        exit(1)
    
    symbol = sys.argv[1]
    result = query_stock_news(symbol, cookie)
    
    print(f"股票代码: {symbol}")
    print(f"股票名称: {result['stock_name']}")
    print(f"获取到 {result['news_count']} 条相关新闻")
    print(f"摘要: {result['summary']}")
    print("\n最近新闻:")
    for i, news in enumerate(result['recent_news'], 1):
        print(f"{i}. {news['title'] or news['content'][:50]}...")