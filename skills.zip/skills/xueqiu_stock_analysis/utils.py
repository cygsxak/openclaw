"""
雪球股票分析技能的辅助工具函数
"""

def format_stock_data(symbol: str, name: str, price: float, change_percent: float) -> dict:
    """
    格式化股票数据
    """
    return {
        "symbol": symbol,
        "name": name,
        "price": round(price, 2),
        "change_percent": round(change_percent, 2),
        "timestamp": __import__('datetime').datetime.now().isoformat()
    }

def calculate_position_size(account_balance: float, risk_per_trade: float, entry_price: float, stop_loss_price: float) -> dict:
    """
    计算头寸规模
    :param account_balance: 账户余额
    :param risk_per_trade: 每笔交易风险金额
    :param entry_price: 入场价格
    :param stop_loss_price: 止损价格
    :return: 包含头寸规模信息的字典
    """
    import math
    
    if entry_price <= stop_loss_price:
        return {"error": "入场价格必须高于止损价格"}
    
    risk_per_share = entry_price - stop_loss_price
    if risk_per_share <= 0:
        return {"error": "无效的风险计算"}
    
    position_size = risk_per_trade / risk_per_share
    investment_amount = position_size * entry_price
    
    # 确保不超过账户余额的一定比例
    max_investment = account_balance * 0.95  # 最多使用95%的资金
    if investment_amount > max_investment:
        position_size = (max_investment * risk_per_share) / (entry_price * risk_per_share)
        investment_amount = min(investment_amount, max_investment)
    
    return {
        "position_size": int(position_size),
        "investment_amount": round(investment_amount, 2),
        "risk_amount": round(risk_per_trade, 2),
        "risk_percentage": round((risk_per_trade / account_balance) * 100, 2)
    }

def normalize_symbol(symbol: str) -> str:
    """
    标准化股票代码格式
    """
    # 移除可能的后缀
    normalized = symbol.replace('.SS', '').replace('.SZ', '').replace('.BJ', '')
    
    # 确保是6位数字
    if len(normalized) < 6:
        normalized = normalized.zfill(6)
    elif len(normalized) > 6:
        # 如果是上交所或深交所的完整代码，提取后6位
        if normalized.startswith(('SH', 'SZ')):
            normalized = normalized[2:]
    
    return normalized

def validate_symbol(symbol: str) -> bool:
    """
    验证股票代码是否有效
    """
    import re
    normalized = normalize_symbol(symbol)
    
    # 检查是否为6位数字
    if not re.match(r'^\d{6}$', normalized):
        return False
    
    # 根据前缀验证市场
    first_digit = normalized[0]
    valid_prefixes = {
        '0': ['000', '001', '002', '003', '080', '081', '082', '083', '084', '085', '086', '087', '088', '089', '090', '091', '092', '093', '094', '095', '096', '097', '098', '099'],
        '3': ['300', '301'],
        '6': ['600', '601', '603', '605', '688', '689']
    }
    
    prefix3 = normalized[:3]
    if first_digit in valid_prefixes:
        return prefix3 in valid_prefixes[first_digit]
    elif first_digit in ['4', '8']:
        # 北交所和新三板
        return True
    else:
        return False

def get_market_from_symbol(symbol: str) -> str:
    """
    从股票代码获取所属市场
    """
    normalized = normalize_symbol(symbol)
    if not normalized or len(normalized) < 3:
        return "Unknown"
    
    prefix3 = normalized[:3]
    if prefix3 in ['600', '601', '603', '605', '688', '689']:
        return "SH"
    elif prefix3 in ['000', '001', '002', '003', '080', '081', '082', '083', '084', '085', '086', '087', '088', '089', '090', '091', '092', '093', '094', '095', '096', '097', '098', '099']:
        return "SZ"
    elif prefix3 in ['300', '301']:
        return "SZ"
    elif prefix3 in ['430', '830', '870', '820', '880']:
        return "BJ"
    else:
        return "Unknown"

def format_analysis_result(result: dict) -> str:
    """
    格式化分析结果为易读的字符串
    """
    if 'error' in result:
        return f"分析失败: {result['error']}"
    
    data = result.get('data', {})
    decision = result.get('decision', {})
    
    formatted = f"""
=== {data.get('name', '未知股票')}({data.get('symbol', 'N/A')}) 分析报告 ===
时间: {result.get('time', 'N/A')}
价格: ¥{data.get('price', 'N/A')}
涨跌幅: {data.get('change_percent', 'N/A')}%

--- 技术指标 ---
趋势: {data.get('technicals', {}).get('trend', 'N/A')}
MA5: {data.get('technicals', {}).get('MA5', 'N/A')}, MA20: {data.get('technicals', {}).get('MA20', 'N/A')}
MACD: DIF={data.get('technicals', {}).get('MACD_DIF', 'N/A')}, DEA={data.get('technicals', {}).get('MACD_DEA', 'N/A')}, HIST={data.get('technicals', {}).get('MACD_HIST', 'N/A')}
RSI14: {data.get('technicals', {}).get('RSI14', 'N/A')}
ATR14: {data.get('technicals', {}).get('ATR14', 'N/A')}
支撑位: {data.get('technicals', {}).get('support', 'N/A')}, 压力位: {data.get('technicals', {}).get('resistance', 'N/A')}
风险提示: {', '.join(data.get('technicals', {}).get('risk_flags', ['无']))}

--- AI决策 ---
操作建议: {decision.get('action', 'N/A')}
建议仓位: {decision.get('weight', 'N/A')}
价格区间: {decision.get('price_range', 'N/A')}
理由: {decision.get('reason', 'N/A')}

--- 评分 ---
基本面: {decision.get('scores', {}).get('fundamental', 'N/A')}/30
技术面: {decision.get('scores', {}).get('technical', 'N/A')}/30
消息面: {decision.get('scores', {}).get('news', 'N/A')}/20
资金面: {decision.get('scores', {}).get('capital', 'N/A')}/20
总分: {decision.get('scores', {}).get('total', 'N/A')}/100
    """.strip()
    
    return formatted

def get_risk_level(rsi_value: float, macd_hist: float, volume_status: str) -> str:
    """
    根据技术指标评估风险等级
    """
    risk_score = 0
    
    # RSI风险评估
    if rsi_value > 70 or rsi_value < 30:
        risk_score += 2
    elif rsi_value > 80 or rsi_value < 20:
        risk_score += 3
    else:
        risk_score += 1
    
    # MACD风险评估
    if macd_hist < 0:
        risk_score += 1
    
    # 成交量风险评估
    if volume_status == "缩量":
        risk_score += 1
    
    if risk_score >= 5:
        return "高风险"
    elif risk_score >= 3:
        return "中风险"
    else:
        return "低风险"