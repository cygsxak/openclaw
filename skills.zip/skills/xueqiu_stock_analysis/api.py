"""
雪球股票分析技能的API接口
"""
from typing import Optional, List, Dict, Any
from .main import analyze_stock, get_hot_stocks, analyze_multiple_stocks
from .utils import format_analysis_result, validate_symbol, normalize_symbol


def api_analyze_single_stock(symbol: str) -> Dict[str, Any]:
    """
    API接口：分析单只股票
    :param symbol: 股票代码
    :return: 分析结果
    """
    if not validate_symbol(symbol):
        return {"error": f"无效的股票代码: {symbol}"}
    
    normalized_symbol = normalize_symbol(symbol)
    result = analyze_stock(normalized_symbol)
    
    # 添加格式化的分析报告
    if 'data' in result and 'decision' in result:
        result['formatted_report'] = format_analysis_result(result)
    
    return result


def api_analyze_multiple_stocks(symbols: List[str]) -> List[Dict[str, Any]]:
    """
    API接口：批量分析多只股票
    :param symbols: 股票代码列表
    :return: 分析结果列表
    """
    validated_symbols = []
    for symbol in symbols:
        if validate_symbol(symbol):
            validated_symbols.append(normalize_symbol(symbol))
        else:
            return {"error": f"无效的股票代码: {symbol}"}
    
    results = analyze_multiple_stocks(validated_symbols)
    
    # 为每个结果添加格式化报告
    for result in results:
        if 'data' in result and 'decision' in result:
            result['formatted_report'] = format_analysis_result(result)
    
    return results


def api_get_hot_stocks() -> Dict[str, Any]:
    """
    API接口：获取热门股票
    :return: 热门股票列表
    """
    return {
        "time": __import__('datetime').datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": get_hot_stocks()
    }


def api_get_technical_indicators(symbol: str) -> Dict[str, Any]:
    """
    API接口：获取股票技术指标
    :param symbol: 股票代码
    :return: 技术指标数据
    """
    if not validate_symbol(symbol):
        return {"error": f"无效的股票代码: {symbol}"}
    
    normalized_symbol = normalize_symbol(symbol)
    result = analyze_stock(normalized_symbol)
    
    if 'error' in result:
        return result
    
    return {
        "symbol": result['data']['symbol'],
        "name": result['data']['name'],
        "time": result['time'],
        "technicals": result['data']['technicals']
    }


def api_get_ai_recommendation(symbol: str) -> Dict[str, Any]:
    """
    API接口：获取AI投资建议
    :param symbol: 股票代码
    :return: AI决策结果
    """
    if not validate_symbol(symbol):
        return {"error": f"无效的股票代码: {symbol}"}
    
    normalized_symbol = normalize_symbol(symbol)
    result = analyze_stock(normalized_symbol)
    
    if 'error' in result:
        return result
    
    return {
        "symbol": result['data']['symbol'],
        "name": result['data']['name'],
        "time": result['time'],
        "recommendation": result['decision']
    }


def api_compare_stocks(symbols: List[str]) -> Dict[str, Any]:
    """
    API接口：比较多只股票的分析结果
    :param symbols: 股票代码列表
    :return: 比较结果
    """
    if len(symbols) < 2:
        return {"error": "至少需要两只股票进行比较"}
    
    results = api_analyze_multiple_stocks(symbols)
    
    if 'error' in results:
        return results
    
    comparison = {
        "comparison_time": __import__('datetime').datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "stocks": [],
        "summary": {
            "highest_rsi": {"symbol": "", "value": 0},
            "lowest_rsi": {"symbol": "", "value": 100},
            "highest_price": {"symbol": "", "value": 0},
            "biggest_gainer": {"symbol": "", "change": 0},
            "biggest_loser": {"symbol": "", "change": 0}
        }
    }
    
    for result in results:
        if 'error' in result:
            continue
            
        data = result['data']
        technicals = data['technicals']
        change_percent = data['change_percent']
        
        stock_summary = {
            "symbol": data['symbol'],
            "name": data['name'],
            "price": data['price'],
            "change_percent": change_percent,
            "rsi": technicals.get('RSI14', 0),
            "trend": technicals.get('trend', '未知'),
            "recommendation": result['decision']['action']
        }
        
        comparison['stocks'].append(stock_summary)
        
        # 更新汇总统计
        rsi = technicals.get('RSI14', 0)
        if rsi > comparison['summary']['highest_rsi']['value']:
            comparison['summary']['highest_rsi'] = {"symbol": data['symbol'], "value": rsi}
        if rsi < comparison['summary']['lowest_rsi']['value']:
            comparison['summary']['lowest_rsi'] = {"symbol": data['symbol'], "value": rsi}
        if data['price'] > comparison['summary']['highest_price']['value']:
            comparison['summary']['highest_price'] = {"symbol": data['symbol'], "value": data['price']}
        if change_percent > comparison['summary']['biggest_gainer']['change']:
            comparison['summary']['biggest_gainer'] = {"symbol": data['symbol'], "change": change_percent}
        if change_percent < comparison['summary']['biggest_loser']['change']:
            comparison['summary']['biggest_loser'] = {"symbol": data['symbol'], "change": change_percent}
    
    return comparison