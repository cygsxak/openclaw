#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
雪球自选股查询模块
"""

import os
import json
import pandas as pd
import requests
import re
import html
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import time


def get_xueqiu_portfolio(cookie: str) -> List[Dict[str, Any]]:
    """
    获取雪球自选股列表
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Cookie': cookie
    }

    # 获取自选股列表
    portfolio_url = 'https://stock.xueqiu.com/v5/stock/portfolio/stock/list.json'
    portfolio_params = {
        'size': '1000',
        'category': '1',
        'pid': '17',
        '_': str(int(time.time() * 1000))
    }

    try:
        response = requests.get(portfolio_url, headers=headers, params=portfolio_params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            stocks = data.get('data', {}).get('stocks', [])
            return stocks
        else:
            print(f'获取自选股列表失败: {response.status_code}')
            return []
    except Exception as e:
        print(f'获取自选股列表异常: {str(e)}')
        return []


def get_stock_quotes(symbols: List[str], cookie: str) -> List[Dict[str, Any]]:
    """
    获取股票实时行情
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Cookie': cookie
    }
    
    # 使用雪球API查询行情，使用新的参数
    quote_url = 'https://stock.xueqiu.com/v5/stock/batch/quote.json'
    quote_params = {
        'symbol': ','.join(symbols),
        'extend': 'detail',
        'is_delay_hk': 'true',
        '_': str(int(time.time() * 1000))
    }
    
    try:
        quote_response = requests.get(quote_url, headers=headers, params=quote_params, timeout=10)
        if quote_response.status_code == 200:
            quote_data = quote_response.json()
            return quote_data.get('data', {}).get('items', [])
        else:
            print(f'获取行情数据失败: {quote_response.status_code}')
            return []
    except Exception as e:
        print(f'获取行情数据异常: {str(e)}')
        return []


def query_my_stocks(cookie: str) -> Dict[str, Any]:
    """
    查询我的自选股实时行情
    """
    # 获取自选股列表
    portfolio_stocks = get_xueqiu_portfolio(cookie)
    
    if not portfolio_stocks:
        return {"error": "未获取到自选股列表"}
    
    # 提取股票代码
    symbols = [stock.get('symbol', '') for stock in portfolio_stocks]
    symbols = [sym for sym in symbols if sym]  # 过滤空值
    
    if not symbols:
        return {"error": "自选股列表中没有有效的股票代码"}
    
    # 获取行情数据
    quotes = get_stock_quotes(symbols, cookie)
    
    # 组合自选股信息和行情数据
    result = []
    for i, stock in enumerate(portfolio_stocks):
        symbol = stock.get('symbol', '')
        name = stock.get('name', 'N/A')
        
        # 查找对应的行情数据
        quote_info = None
        for item in quotes:
            if item.get('quote', {}).get('symbol', '') == symbol:
                quote_info = item.get('quote', {})
                break
        
        stock_data = {
            'index': i + 1,
            'name': name,
            'symbol': symbol,
            'current': 'N/A',
            'change': 'N/A',
            'change_percent': 'N/A',
            'volume': 'N/A',
            'market_cap': 'N/A'
        }
        
        if quote_info:
            current = quote_info.get('current', 'N/A')
            chg = quote_info.get('chg', 'N/A')
            percent = quote_info.get('percent', 'N/A')  # 使用percent而不是chg_pct
            volume = quote_info.get('volume', 'N/A')
            market_cap = quote_info.get('market_capital', 'N/A')
            
            # 确保数值是数字类型才能格式化
            stock_data.update({
                'current': current if current != 'N/A' else 0,
                'change': chg if chg != 'N/A' else 0,
                'change_percent': percent if percent != 'N/A' else 0,
                'volume': volume if volume != 'N/A' and volume else 'N/A',
                'market_cap': market_cap if market_cap != 'N/A' and market_cap else 'N/A'
            })
        
        result.append(stock_data)
    
    return {
        "stocks": result,
        "total_count": len(result),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }


if __name__ == "__main__":
    # 使用默认cookie值
    cookie = 's=ak16ifihe4; cookiesu=481770170902383; Hm_lvt_1db88642e346389874251b5a1eded6e3=1770170905; HMACCOUNT=926D01031F8F8510; device_id=67dc5b6be5358d3e2d38ada620f024d7; xq_a_token=0f49dbc43aabce03285668102b697d110abf0287; xqat=0f49dbc43aabce03285668102b697d110abf0287; xq_r_token=9fc624b8389d5c731ff388108023728b9a7fd6e7; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOjQ4MzUwMzY0NjIsImlzcyI6InVjIiwiZXhwIjoxNzcxOTM4Nzg3LCJjdG0iOjE3NzAxNzA5Njg1MTYsImNpZCI6ImQ5ZDBuNEFadXAifQ.d1JX1zqGxgyDu6hmcSqMgRlxtIYfEbReelmhGlzcSMblhuANPPqhMij1FiABwaaT4yDwVh4tj2Si1BJKuVYBM2LwgokiClu8nytC_x-Z9SAN7xF0e1enCyabRGRy7B6cAyYM9Gl3buFI8dQweu1fxuibgvlws0lNvuQ1r-P57Ii-f_HDr7Ur6_dh5yaXVa0SmWS58CDHXvAj4XC1mYhJSGV7k-I5O9-UuMEYaGfl8NptNR_78BGk0ctU3LioVqLOY3x3akOSjhENJNcJ3cpXZft1jH7jMerSmXTZS7IiEFfbr0CqnpCtQ05YEYX4wpgk_YnE1drKQjXJNM0FqGexCg; xq_is_login=1; u=4835036462; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1770170974; ssxmod_itna=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OiNDlELeDZDGIQDqx0EbRWWioiKS_lQwYoZRjAEAQP8U22hIQb0AEkyrbvO1kRfyG6MzfDXtAeDU4GnD0=m3ohbDYYjDBYD74G_DDeDixGm7eDSbxD9DGp=qpnbMeDEDYPaxitPOgaOxDLW9jROvDDBIb2d72u4DDX4dnxoN0xOxGYPv=pde1GAwY_=x0tFDBdKDXG=xtl2dYcAuzk7kfbDzdzDtLWzqZ_8lCaTh6mQYvDF4XmKD9e40KKCGqQeXiD4ehteA590xBG=0GPKoXehzi0bDDASriSh5=medhlfyZWPwn5mDA170D9iTBqCIToKDk9iqlGO3hqS2N4br4Rr/iozDKNG4Tbx1GDD; ssxmod_itna2=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OioDicwBKrpBmD03q7YR8Ie58DGXYFd7=452wp=Dkx0qWNKUBh7OwWj4LQRG=wBQSddjbDQOQR3O/4Lq_0=Ob7Lcmd4qNiRY9DL3NlGecCDrDM3O94NtblQVDwx=Exn3sYrrC0fqt_xqw7G8NiitNLjiHaKK3qn5cCjQ5iH9GCX4Hdc==jNPkTHRj8qtoa0INncM9008pTS670tqXSUV3KdL3RR6NR0vxy0cdpBLxPzHuTK08oSH8wKudHpEQtbW=nQn4Q88GVh=c_GZxaBO8Yh1Zu59_Tz8G_3hwOq0kQpgqYjNyfGRDWpMiuRFgfIoCtpohk0xGhvRgvQnQM4AIOz5DQzbt3=qwriFC1ZfC82Q4Lbki7jqtRdwzbv3pWWmIgqdIl84bExcFUxjXQHbSGN=rUu=OibUdHlor7jbVYatRQq0vSfDy21fQq4kGbTN7ezK03o98mQk5fQr61Ch7r7pHtqNqFSS6sms8lv2TvhuaqmTU8noWI/LUawvLTx56wa_657hKmrSzOPAiiQnaRTLqNz4Gj8NOLQ357TI7jxWhkQBFEcWiPG3NpHZDfoigY70gb0axdQB3vhx=uuC2qLsdM4/OUYkS_qYxVQ/Bpb7q5ECbN6_iU4EBN/NqmVfXQDZRj=iS7wUDYbqgk4d3yYZehM0fljig42dNj/tD5Ae3xXTPdhTn5D4s0rQ4/kqb28C3A2YiDD'
    
    result = query_my_stocks(cookie)
    
    if "error" in result:
        print(f"查询失败: {result['error']}")
    else:
        print(f"您的自选股实时行情 (共{result['total_count']}只):")
        print("="*80)
        
        for stock in result['stocks']:
            print(f"{stock['index']:2d}. {stock['name']} ({stock['symbol']})")
            print(f"    价格: {stock['current']} ({stock['change']:+.2f}, {stock['change_percent']:+.2f}%)")
            
            if stock['volume'] != 'N/A':
                try:
                    vol_val = float(stock['volume'])
                    vol_str = f'{vol_val/10000:.2f}万手'
                except (ValueError, TypeError):
                    vol_str = str(stock['volume'])
                print(f"    成交量: {vol_str}")
            else:
                print(f"    成交量: N/A")
                
            if stock['market_cap'] != 'N/A':
                try:
                    cap_val = float(stock['market_cap'])
                    cap_str = f'{cap_val/100000000:.2f}亿'
                except (ValueError, TypeError):
                    cap_str = str(stock['market_cap'])
                print(f"    市值: {cap_str}")
            else:
                print(f"    市值: N/A")
            print()