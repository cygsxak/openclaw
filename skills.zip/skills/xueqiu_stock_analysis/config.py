"""
雪球股票分析技能配置文件
"""

# API配置
API_CONFIG = {
    "google_api_key": "${GOOGLE_API_KEY}",  # 通过环境变量获取
    "model_provider": "gemini",
    "model_configs": {
        "gemini": {
            "api_key": "${GOOGLE_API_KEY}",
            "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
            "model": "gemini-2.5-flash"
        }
    },
    "xueqiu_token": "${XUEQIU_TOKEN}"  # 通过环境变量获取
}

# 分析配置
ANALYSIS_CONFIG = {
    # 最大仓位百分比
    "max_portfolio_percent": 0.25,
    
    # 技术指标参数
    "ma_short_period": 5,      # 短期移动平均线周期
    "ma_long_period": 20,      # 长期移动平均线周期
    "macd_fast": 12,           # MACD快线周期
    "macd_slow": 26,           # MACD慢线周期
    "macd_signal": 9,          # MACD信号线周期
    "rsi_period": 14,          # RSI周期
    "atr_period": 14,          # ATR周期
    
    # 风险管理参数
    "risk_thresholds": {
        "high_rsi": 70,        # RSI过高阈值
        "low_rsi": 30,         # RSI过低阈值
        "max_volatility": 0.08 # 最大波动率
    },
    
    # 数据回溯天数
    "history_days": 60
}

# 指数配置
INDEX_CONFIG = {
    "000001": "上证指数",
    "399001": "深证成指",
    "399006": "创业板指",
    "000300": "沪深300",
    "000016": "上证50",
    "399333": "中小板综",
    "399005": "中小板指"
}

# 市场配置
MARKET_CONFIG = {
    "shanghai": {
        "prefixes": ["600", "601", "603", "605", "688", "689"],
        "timezone": "Asia/Shanghai"
    },
    "shenzhen": {
        "prefixes": ["000", "001", "002", "003", "300", "301"],
        "timezone": "Asia/Shanghai"
    },
    "beijing": {
        "prefixes": ["430", "830", "870", "820", "880"],
        "timezone": "Asia/Shanghai"
    }
}

# 缓存配置
CACHE_CONFIG = {
    "enabled": True,
    "ttl_minutes": 5,  # 缓存时间（分钟）
    "max_size": 1000   # 最大缓存条目数
}

# 日志配置
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "handlers": ["console", "file"],
    "file_path": "./logs/xueqiu_analysis.log"
}

def get_config():
    """
    获取完整配置
    """
    return {
        "api": API_CONFIG,
        "analysis": ANALYSIS_CONFIG,
        "index": INDEX_CONFIG,
        "market": MARKET_CONFIG,
        "cache": CACHE_CONFIG,
        "logging": LOGGING_CONFIG
    }

def update_config(key: str, value):
    """
    更新配置值
    """
    global API_CONFIG, ANALYSIS_CONFIG, INDEX_CONFIG, MARKET_CONFIG, CACHE_CONFIG, LOGGING_CONFIG
    
    if key == "api":
        API_CONFIG.update(value)
    elif key == "analysis":
        ANALYSIS_CONFIG.update(value)
    elif key == "index":
        INDEX_CONFIG.update(value)
    elif key == "market":
        MARKET_CONFIG.update(value)
    elif key == "cache":
        CACHE_CONFIG.update(value)
    elif key == "logging":
        LOGGING_CONFIG.update(value)