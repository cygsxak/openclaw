import os
import json
import pandas as pd
import requests
import re
import html
import akshare as ak
from datetime import datetime, timedelta
from openai import OpenAI
import time
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
import warnings
from typing import Optional, List, Dict, Any, Tuple

# 配置区
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "YOUR_GOOGLE_API_KEY_HERE")
MODEL_PROVIDER = "gemini"
MODEL_CONFIGS = {
    "gemini": {
        "api_key": GOOGLE_API_KEY,
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
        "model": "gemini-2.5-flash"
    }
}
CURRENT_CONFIG = MODEL_CONFIGS["gemini"]

# 雪球 Token
XUEQIU_TOKEN = os.getenv("XUEQIU_TOKEN", "")

# 限制最大仓位百分比
MAX_PORTFOLIO_PERCENT = 0.25

# 指数名称映射
INDEX_NAME_MAP = {
    "000001": "上证指数",
    "399001": "深证成指",
}

def safe_float(x, default=0.0) -> float:
    """安全转换为浮点数"""
    try:
        if x is None:
            return default
        if isinstance(x, (float, int)):
            return float(x)
        s = str(x).replace(",", "").strip()
        if s in ["", "-", "None", "nan", "NaN"]:
            return default
        return float(s)
    except Exception:
        return default

def clamp_weight(w: float, max_w: float = MAX_PORTFOLIO_PERCENT) -> float:
    """限制权重在合理范围内"""
    try:
        return round(max(0.0, min(max_w, float(w))), 3)
    except Exception:
        return 0.0

def compute_indicators(df: pd.DataFrame) -> Dict[str, Any]:
    """
    根据 A 股历史数据 DataFrame 计算常用技术指标:
    - MA5, MA20
    - MACD(12,26,9)
    - RSI(14)
    - ATR(14)
    - 简易趋势、支撑/压力位
    DataFrame 需要包含列: ['开盘','收盘','最高','最低']
    """
    out = {}
    if df is None or df.empty or not set(['开盘', '收盘', '最高', '最低']).issubset(df.columns):
        return out
    
    close = pd.to_numeric(df['收盘'], errors='coerce')
    high = pd.to_numeric(df['最高'], errors='coerce')
    low = pd.to_numeric(df['最低'], errors='coerce')
    
    # MA
    ma5 = close.rolling(5).mean()
    ma20 = close.rolling(20).mean()
    
    # MACD
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    dif = ema12 - ema26
    dea = dif.ewm(span=9, adjust=False).mean()
    macd_hist = dif - dea
    
    # RSI14
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()
    
    # 防止除零
    rs = avg_gain / (avg_loss.replace(0, pd.NA))
    rsi14 = 100 - (100 / (1 + rs.replace(pd.NA, 1e9)))
    
    # ATR14
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)
    atr14 = tr.rolling(14).mean()
    
    out['MA5'] = safe_float(ma5.iloc[-1])
    out['MA20'] = safe_float(ma20.iloc[-1])
    out['MACD_DIF'] = safe_float(dif.iloc[-1])
    out['MACD_DEA'] = safe_float(dea.iloc[-1])
    out['MACD_HIST'] = safe_float(macd_hist.iloc[-1])
    out['RSI14'] = safe_float(rsi14.iloc[-1], default=50.0)
    out['ATR14'] = safe_float(atr14.iloc[-1], default=0.0)
    
    # 趋势判断
    if not pd.isna(out['MA5']) and not pd.isna(out['MA20']):
        out['trend'] = '上行' if out['MA5'] >= out['MA20'] else '下行'
    else:
        out['trend'] = '未知'
    
    # 最近20日的支撑/压力位
    window = df.tail(20)
    if not window.empty:
        out['support'] = safe_float(window['最低'].min())
        out['resistance'] = safe_float(window['最高'].max())
    
    # 风险标志
    out['risk_flags'] = []
    if out['RSI14'] >= 70:
        out['risk_flags'].append('RSI过热')
    elif out['RSI14'] <= 30:
        out['risk_flags'].append('RSI超卖')
    if out['MACD_HIST'] < 0:
        out['risk_flags'].append('动能偏弱')
    
    return out

def suggest_price_range(current_price: float, atr: float, support: float = None, resistance: float = None) -> str:
    """
    根据 ATR 与支撑/压力位给出参考价格区间。
    - 以 ATR 的 0.8~1.2 倍在当前价附近给出区间
    - 如存在支撑/压力位，适当收敛区间
    """
    cp = safe_float(current_price)
    a = safe_float(atr)
    if cp <= 0:
        return ""
    
    low = cp - max(a * 0.8, cp * 0.01)
    high = cp + max(a * 1.2, cp * 0.01)
    
    if support and support > 0:
        low = max(low, support * 0.98)
    if resistance and resistance > 0:
        high = min(high, resistance * 1.02)
    
    return f"{round(low, 2)}-{round(high, 2)}"

class XueQiuStockAnalyzer:
    def __init__(self, symbol: str):
        """初始化雪球股票分析器"""
        self.symbol = symbol.strip()
        self.full_symbol = self._get_full_symbol(self.symbol)
        self._stock_name = None
        
    @property
    def stock_name(self) -> str:
        return self.get_stock_name()
    
    def _get_full_symbol(self, code: str) -> str:
        """根据代码判断市场并添加后缀"""
        # 指数特殊处理
        if code in INDEX_NAME_MAP:
            return code  # 指数不加后缀
        if code.startswith('6'):
            return f"{code}.SS"  # 上海
        elif code.startswith(('0', '3')):
            return f"{code}.SZ"  # 深圳
        return code
    
    def get_stock_name(self) -> str:
        """获取股票名称；指数返回中文名"""
        if self._stock_name:
            return self._stock_name
        if self.symbol in INDEX_NAME_MAP:
            return INDEX_NAME_MAP.get(self.symbol, self.symbol)
        
        try:
            # 优化市场前缀判断逻辑
            if self.symbol.startswith(('5', '6', '9')):
                prefix = 'sh'
            elif self.symbol.startswith(('0', '1', '2', '3')):
                prefix = 'sz'
            elif self.symbol.startswith(('4', '8')):
                prefix = 'bj'
            else:
                prefix = 'sh' if self.symbol.startswith('6') else 'sz'
            
            url = f"http://hq.sinajs.cn/list={prefix}{self.symbol}"
            headers = {
                "Referer": "https://finance.sina.com.cn",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
            response = requests.get(url, headers=headers, timeout=5)
            if response.status_code == 200:
                # 显式使用 gbk 解码
                text = response.content.decode('gbk', errors='ignore')
                if '="' in text:
                    data = text.split('"')[1].split(',')
                    name = data[0] if data and len(data[0]) > 0 else self.symbol
                    self._stock_name = name
                    return name
        except Exception:
            pass
        return self.symbol

    def get_market_intelligence(self) -> Optional[Dict[str, Any]]:
        """获取股票市场情报"""
        try:
            end_date = datetime.now().strftime("%Y%m%d")
            start_date = (datetime.now() - timedelta(days=60)).strftime("%Y%m%d")
            
            # 指数处理
            if self.symbol in INDEX_NAME_MAP:
                df = self._get_index_df(start_date, end_date)
                if df is None or df.empty:
                    print(f"{self.symbol}: 未找到指数数据")
                    return None
            else:
                df = ak.stock_zh_a_hist(symbol=self.symbol, period="daily", 
                                       start_date=start_date, end_date=end_date, adjust="")
                if df is None or df.empty:
                    # 兜底：尝试东财实时全量数据中提取最新一行
                    try:
                        spot = ak.stock_zh_a_spot_em()
                        row = spot[spot['代码'] == self.symbol]
                        if row.empty:
                            print(f"{self.symbol}: 未找到股票数据")
                            return None
                        latest_row = row.iloc[-1]
                        df = pd.DataFrame([{
                            '日期': datetime.now().strftime("%Y%m%d"),
                            '开盘': safe_float(latest_row.get('今开')),
                            '收盘': safe_float(latest_row.get('最新价')),
                            '最高': safe_float(latest_row.get('最高')),
                            '最低': safe_float(latest_row.get('最低')),
                            '成交量': safe_float(latest_row.get('成交量')),
                            '成交额': safe_float(latest_row.get('成交额')),
                        }])
                    except Exception as e:
                        print(f"{self.symbol}: df兜底失败 - {e}")
                        return None
            
            latest = df.iloc[-1]
            current_price = safe_float(latest['收盘'])
            open_price = safe_float(latest['开盘'])
            high_price = safe_float(latest['最高'])
            low_price = safe_float(latest['最低'])
            volume = safe_float(latest.get('成交量', 0))  # 手
            amount_raw = safe_float(latest.get('成交额', 0))  # 元
            amount_ye = round(amount_raw / 100000000, 2)  # 转亿
            
            # 涨跌幅
            if len(df) > 1 and not pd.isna(df.iloc[-2]['收盘']):
                yesterday_close = safe_float(df.iloc[-2]['收盘'], default=current_price)
                change_percent = ((current_price - yesterday_close) / yesterday_close * 100) if yesterday_close > 0 else 0
            else:
                change_percent = 0.0
            
            # 波动率（高低价差/开盘价）
            volatility = ((high_price - low_price) / open_price) if open_price > 0 else 0.0
            
            # 成交量状态
            if amount_raw > 1000000000:
                volume_status = "放量"
            elif amount_raw > 300000000:
                volume_status = "正常"
            else:
                volume_status = "缩量"
            
            stock_name = self.get_stock_name()
            
            # 技术指标
            technicals = compute_indicators(df)
            
            # 获取价格区间建议
            price_range_hint = suggest_price_range(
                current_price,
                technicals.get('ATR14', 0.0),
                technicals.get('support'),
                technicals.get('resistance')
            )
            
            intel = {
                "symbol": self.symbol,
                "name": stock_name,
                "price": round(current_price, 2),
                "change_percent": round(change_percent, 2),
                "open": round(open_price, 2),
                "high": round(high_price, 2),
                "low": round(low_price, 2),
                "volume": round(volume, 2),  # 手
                "amount": amount_ye,  # 亿元
                "volatility": round(volatility, 4),
                "volume_status": volume_status,
                "technicals": technicals,
                "price_range_hint": price_range_hint,
            }
            
            return intel
        except Exception as e:
            print(f"{self.symbol}: 数据获取失败 - {str(e)}")
            import traceback
            traceback.print_exc()
            return None

    def get_ai_decision(self, intelligence: Dict[str, Any]) -> Dict[str, Any]:
        """调用AI进行投资决策分析"""
        tech = intelligence.get('technicals', {}) or {}
        risk_flags_list = tech.get('risk_flags', [])
        risk_flags_str = ",".join(risk_flags_list) if risk_flags_list else "无明显风险"
        
        tech_text = (
            f"MA5: {tech.get('MA5','-')}, MA20: {tech.get('MA20','-')}, "
            f"MACD: DIF {tech.get('MACD_DIF','-')}, DEA {tech.get('MACD_DEA','-')}, HIST {tech.get('MACD_HIST','-')}; "
            f"RSI14: {tech.get('RSI14','-')}; ATR14: {tech.get('ATR14','-')}; "
            f"趋势: {tech.get('trend','未知')}; 支撑: {tech.get('support','-')}, 压力: {tech.get('resistance','-')}; "
            f"风险提示: {risk_flags_str}"
        )
        
        prompt = f"""
        你是一位资深A股分析师。请根据以下实时数据对 {intelligence['name']}({intelligence['symbol']}) 进行判断：

        实时行情：
        - 当前价格: ¥{intelligence['price']}
        - 涨跌幅: {intelligence['change_percent']}%
        - 今开: ¥{intelligence['open']} | 最高: ¥{intelligence['high']} | 最低: ¥{intelligence['low']}
        - 成交量: {intelligence['volume']}手 | 成交额: {intelligence['amount']}亿元
        - 市场波动率: {intelligence['volatility']}
        - 成交量状态: {intelligence['volume_status']}
        - 技术指标: {tech_text}
        - 参考价格区间(ATR): {intelligence.get('price_range_hint','')}

        任务：
        1. 【风控优先原则】：首先仔细检查技术指标-风险提示中是否存在重大负面利空（如：RSI过热、动能偏弱等）。
        2. 结合A股市场特点、当前政策环境、行业趋势进行分析。
        3. 综合考虑技术指标和市场情绪。
        4. 考虑涨跌幅限制（10%或20%）、T+1交易制度等A股特有规则。
        5. 给出交易动作：BUY（买入）、SELL（卖出）或 HOLD（观望）。
        6. 给出建议持仓比例 (0.0 到 {MAX_PORTFOLIO_PERCENT})。
        7. 给出参考价格区间（price_range字段，格式："min-max"，例如："15.50-16.80"）。
        8. 用中文详细说明决策逻辑。
        9. 请根据以下四个维度进行打分（总分100分）：
           - 基本面评分 (0-30分)：依据技术指标和市场表现。
           - 技术面评分 (0-30分)：依据趋势、均线、MACD、RSI、ATR、支撑压力位。
           - 消息面评分 (0-20分)：依据新闻舆情、公告内容。
           - 资金面评分 (0-20分)：依据成交量/额等。
           - 总分 (total)：上述四项之和。

        必须以 JSON 格式返回：
        {{
          "action": "BUY/SELL/HOLD",
          "weight": 0.15,
          "price_range": "15.50-16.80",
          "reason": "详细的中文分析理由...",
          "scores": {{
            "fundamental": 25,
            "technical": 20,
            "news": 15,
            "capital": 10,
            "total": 70
          }}
        }}

        注意：
        - 再次强调：对于技术指标显示的风险，应谨慎对待
        - 如果涨幅超过5%需谨慎追高
        - 如果跌幅超过5%需评估是否抄底机会
        """
        
        try:
            client = OpenAI(
                api_key=CURRENT_CONFIG["api_key"],
                base_url=CURRENT_CONFIG["base_url"]
            )
            
            response = client.chat.completions.create(
                model=CURRENT_CONFIG["model"],
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            content = content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            
            decision = json.loads(content, strict=False)
            
            # 确保分数字段存在
            if 'scores' not in decision:
                decision['scores'] = {
                    "fundamental": 0,
                    "technical": 0,
                    "news": 0,
                    "capital": 0,
                    "total": 0
                }
            
            # 基于技术指标调整决策
            base_w = clamp_weight(float(decision.get('weight', 0) or 0))
            action = decision.get('action', 'HOLD')
            
            # 技术趋势
            trend = tech.get('trend', '未知')
            rsi = safe_float(tech.get('RSI14', 50))
            macd_hist = safe_float(tech.get('MACD_HIST', 0))
            atr = safe_float(tech.get('ATR14', 0))
            
            # 趋势与动能
            if trend == '上行' and macd_hist > 0:
                base_w = clamp_weight(base_w + 0.03)
                if action != 'SELL':
                    action = 'BUY'
            
            # RSI过热处理
            if rsi >= 70:
                base_w = clamp_weight(base_w * 0.6)
                if action == 'BUY':
                    action = 'HOLD'
            
            # RSI超卖处理
            if rsi <= 30 and macd_hist >= 0:
                base_w = clamp_weight(base_w + 0.02)
                if action == 'HOLD':
                    action = 'BUY'
            
            decision['weight'] = base_w
            decision['action'] = action
            
            # 当模型未给出价格区间时，采用ATR区间
            pr = decision.get('price_range') or intelligence.get('price_range_hint') or ""
            if not pr:
                price = safe_float(intelligence.get('price', 0))
                pr = suggest_price_range(price, atr, tech.get('support'), tech.get('resistance'))
            decision['price_range'] = pr
            
            return decision
        except Exception as e:
            return {
                "action": "HOLD", 
                "weight": 0, 
                "reason": f"AI服务调用失败: {str(e)}", 
                "confidence": 0.0, 
                "risk_flags": ["AI失败"]
            }

    def _get_index_df(self, start_date: str, end_date: str) -> Optional[pd.DataFrame]:
        """获取指数历史数据"""
        try:
            if self.symbol == "000001":
                sym = "sh000001"
            elif self.symbol == "399001":
                sym = "sz399001"
            else:
                return None
            
            df = ak.stock_zh_index_daily(symbol=sym)
            if df is None or df.empty:
                return None
            
            # 统一列名为A股风格
            rename_map = {
                'date': '日期',
                'open': '开盘',
                'close': '收盘',
                'high': '最高',
                'low': '最低',
                'volume': '成交量',
                'amount': '成交额',
                '日期': '日期',
                '开盘': '开盘',
                '收盘': '收盘',
                '最高': '最高',
                '最低': '最低',
                '成交量': '成交量',
                '成交额': '成交额'
            }
            df = df.rename(columns=rename_map)
            
            # 过滤日期区间
            try:
                df['日期'] = pd.to_datetime(df['日期']).dt.strftime("%Y%m%d")
            except Exception:
                df['日期'] = df['日期'].astype(str).str.replace("-", "")
            df = df[(df['日期'] >= start_date) & (df['日期'] <= end_date)]
            
            # 转换数值
            for col in ['开盘', '收盘', '最高', '最低', '成交量', '成交额']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            return df
        except Exception as e:
            print(f"指数数据获取失败: {e}")
            return None

def analyze_stock(symbol: str) -> Dict[str, Any]:
    """分析单只股票"""
    analyzer = XueQiuStockAnalyzer(symbol)
    
    # 获取市场情报
    intelligence = analyzer.get_market_intelligence()
    if not intelligence:
        return {
            "symbol": symbol,
            "error": "无法获取数据",
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    
    # 获取AI决策
    decision = analyzer.get_ai_decision(intelligence)
    
    result = {
        "symbol": symbol,
        "name": intelligence['name'],
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data": intelligence,
        "decision": decision
    }
    
    return result

def get_hot_stocks() -> List[Dict[str, Any]]:
    """获取雪球热门股票"""
    if not XUEQIU_TOKEN:
        return [{"error": "缺少XUEQIU_TOKEN配置"}]
    
    try:
        headers = {
            'origin': 'https://xueqiu.com',
            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36',
            'cookie': f'xq_a_token={XUEQIU_TOKEN};'
        }
        
        # 获取热股
        url = "https://stock.xueqiu.com/v5/stock/hot_stock/list.json"
        params = {
            "page": "1",
            "size": "100",
            "order": "desc",
            "order_by": "value",
            "type": "10",
            "_": str(int(time.time() * 1000)),
            "x": "0.5"
        }
        
        resp = requests.get(url, params=params, headers=headers, timeout=8)
        if resp.status_code == 200:
            data = resp.json()
            raw_items = data.get('data', {}).get('items', []) or []
            
            hot_stocks = []
            for item in raw_items:
                hot_stocks.append({
                    "name": item.get('name'),
                    "symbol": item.get('symbol'),
                    "price": item.get('current'),
                    "change_percent": item.get('percent'),
                    "increment": item.get('increment')
                })
            
            return hot_stocks
        else:
            return [{"error": f"API请求失败: {resp.status_code}", "text": resp.text}]
    except Exception as e:
        return [{"error": str(e)}]

def analyze_multiple_stocks(symbols: List[str]) -> List[Dict[str, Any]]:
    """批量分析多只股票"""
    results = []
    
    # 控制并发度
    max_workers = min(4, len(symbols))
    if max_workers > 1:
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(analyze_stock, s): s for s in symbols}
            for future in as_completed(futures):
                try:
                    results.append(future.result())
                except Exception as e:
                    sym = futures.get(future, "")
                    results.append({
                        "symbol": sym,
                        "error": f"分析失败: {e}",
                        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })
    else:
        for s in symbols:
            results.append(analyze_stock(s))
    
    return results

# 以下是所需的类型定义，补充缺失的导入
from typing import Optional, List, Dict, Any, Tuple

# 在文件开头添加缺失的导入
import warnings
warnings.filterwarnings(
    "ignore",
    category=FutureWarning,
    message=r".*Passing literal html to 'read_html' is deprecated.*"
)

# 修复相对导入问题
if __name__ == "__main__" or __package__ is None:
    # 如果作为脚本运行或包名为空，手动添加到路径
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))