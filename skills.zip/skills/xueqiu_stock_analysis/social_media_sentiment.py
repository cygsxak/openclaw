#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
股票社交媒体情绪分析模块
获取股票在雪球、微博等社交媒体平台的讨论情绪
"""

import os
import json
import pandas as pd
import requests
import re
import html
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import time
import jieba
from collections import Counter


def get_xueqiu_discussion_sentiment(symbol: str, cookie: str) -> Dict[str, Any]:
    """
    获取雪球社区关于股票的讨论情绪
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Cookie': cookie,
        'Referer': f'https://xueqiu.com/S/{symbol}'
    }
    
    # 获取股票名称
    stock_name = symbol
    try:
        name_headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        # 根据股票代码获取股票名称
        if symbol.startswith(('SH', 'SZ')):
            code = symbol[2:]
        else:
            if symbol.startswith(('5', '6', '9')):
                prefix = 'sh'
            elif symbol.startswith(('0', '1', '2', '3')):
                prefix = 'sz'
            else:
                prefix = 'sz'
            code = symbol
        
        name_url = f'http://hq.sinajs.cn/list={prefix}{code}'
        name_response = requests.get(name_url, headers=name_headers, timeout=5)
        if name_response.status_code == 200:
            text = name_response.content.decode('gbk', errors='ignore')
            if '="' in text:
                data = text.split('"')[1].split(',')
                if data and len(data[0]) > 0:
                    stock_name = data[0]
    except:
        stock_name = symbol

    discussion_data = []
    
    try:
        # 尝试使用雪球搜索API搜索股票相关的讨论
        search_url = 'https://xueqiu.com/statuses/search.json'
        search_params = {
            'q': stock_name,  # 使用股票名称搜索
            'page': 1,
            'size': 20,
            '_': str(int(time.time() * 1000))
        }
        
        response = requests.get(search_url, headers=headers, params=search_params, timeout=10)
        if response.status_code == 200:
            # 检查是否是JSON格式
            content_type = response.headers.get('content-type', '')
            if 'application/json' in content_type:
                try:
                    data = response.json()
                    if 'items' in data and data['items']:
                        items = data['items']
                        
                        for item in items:
                            if item and isinstance(item, dict):
                                text = item.get('text', '')
                                title = item.get('title', '')
                                created_at = item.get('created_at', '')
                                user = item.get('user', {}).get('screen_name', '未知用户')
                                
                                # 检查是否包含股票代码或名称
                                text_lower = text.lower()
                                symbol_lower = symbol.lower()
                                name_lower = stock_name.lower() if stock_name != symbol else ""
                                
                                if symbol_lower in text_lower or name_lower in text_lower:
                                    # 清理文本内容
                                    clean_text = re.sub(r'<.*?>', '', text)  # 移除HTML标签
                                    clean_text = html.unescape(clean_text)  # 处理HTML实体
                                    
                                    discussion_data.append({
                                        'text': clean_text,
                                        'author': user,
                                        'time': created_at,
                                        'platform': '雪球'
                                    })
                except ValueError:
                    print('雪球API返回非JSON格式内容')
    except Exception as e:
        print(f'获取雪球讨论数据异常: {str(e)}')
    
    return {
        'platform': '雪球',
        'discussions': discussion_data,
        'count': len(discussion_data)
    }


def get_weibo_sentiment(symbol: str) -> Dict[str, Any]:
    """
    获取微博关于股票的讨论情绪（模拟实现，实际需要微博API）
    """
    # 由于微博API需要认证，这里提供一个框架实现
    # 实际应用中需要接入微博开放平台API
    
    stock_name = symbol
    try:
        # 获取股票名称
        name_headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        # 根据股票代码获取股票名称
        if symbol.startswith(('SH', 'SZ')):
            code = symbol[2:]
        else:
            if symbol.startswith(('5', '6', '9')):
                prefix = 'sh'
            elif symbol.startswith(('0', '1', '2', '3')):
                prefix = 'sz'
            else:
                prefix = 'sz'
            code = symbol
        
        name_url = f'http://hq.sinajs.cn/list={prefix}{code}'
        name_response = requests.get(name_url, headers=name_headers, timeout=5)
        if name_response.status_code == 200:
            text = name_response.content.decode('gbk', errors='ignore')
            if '="' in text:
                data = text.split('"')[1].split(',')
                if data and len(data[0]) > 0:
                    stock_name = data[0]
    except:
        stock_name = symbol
    
    # 模拟微博讨论数据
    weibo_discussions = [
        {
            'text': f'今天{stock_name}跌得有点狠，不知道是不是利空消息影响',
            'author': '股民小王',
            'time': (datetime.now() - timedelta(hours=2)).strftime('%Y-%m-%d %H:%M:%S'),
            'platform': '微博'
        },
        {
            'text': f'{stock_name}的基本面还是不错的，这次调整可能是市场情绪影响',
            'author': '价值投资者',
            'time': (datetime.now() - timedelta(hours=5)).strftime('%Y-%m-%d %H:%M:%S'),
            'platform': '微博'
        },
        {
            'text': f'抄底{stock_name}的时机到了吗？求大佬指点',
            'author': '新手股民',
            'time': (datetime.now() - timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S'),
            'platform': '微博'
        }
    ]
    
    return {
        'platform': '微博',
        'discussions': weibo_discussions,
        'count': len(weibo_discussions)
    }


def analyze_sentiment_cn(text: str) -> float:
    """
    中文文本情绪分析（简化版）
    返回情绪分数：-1（极度负面）到1（极度正面）
    """
    # 使用jieba分词
    words = jieba.lcut(text)
    
    # 简单的情绪词典（实际应用中应使用更全面的词典）
    positive_words = ['好', '强', '涨', '利好', '买', '增长', '盈利', '上涨', '强势', '推荐', '机会', '复苏', '回升', '新高']
    negative_words = ['坏', '弱', '跌', '利空', '卖', '下跌', '亏损', '风险', '减持', '退市', '问题', '下跌', '破位', '减持']
    
    pos_count = sum(1 for word in words if word in positive_words)
    neg_count = sum(1 for word in words if word in negative_words)
    
    # 计算情绪分数
    total_words = len(words)
    if total_words == 0:
        return 0.0
    
    sentiment_score = (pos_count - neg_count) / total_words
    # 限制在-1到1之间
    return max(-1.0, min(1.0, sentiment_score))


def calculate_overall_sentiment(discussion_platforms: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    计算总体情绪分析结果
    """
    all_texts = []
    total_count = 0
    
    for platform_data in discussion_platforms:
        discussions = platform_data.get('discussions', [])
        for disc in discussions:
            text = disc.get('text', '')
            if text:
                all_texts.append(text)
        total_count += len(discussions)
    
    if not all_texts:
        return {
            'overall_score': 0.0,
            'sentiment_label': '中性',
            'positive_ratio': 0.0,
            'negative_ratio': 0.0,
            'neutral_ratio': 1.0,
            'total_discussions': 0
        }
    
    # 分析每条文本的情绪
    sentiments = [analyze_sentiment_cn(text) for text in all_texts]
    
    # 统计情绪分布
    positive_count = sum(1 for s in sentiments if s > 0.1)
    negative_count = sum(1 for s in sentiments if s < -0.1)
    neutral_count = sum(1 for s in sentiments if -0.1 <= s <= 0.1)
    
    # 计算平均情绪分数
    avg_sentiment = sum(sentiments) / len(sentiments) if sentiments else 0.0
    
    # 情绪标签
    if avg_sentiment > 0.2:
        sentiment_label = '正面'
    elif avg_sentiment < -0.2:
        sentiment_label = '负面'
    else:
        sentiment_label = '中性'
    
    return {
        'overall_score': round(avg_sentiment, 3),
        'sentiment_label': sentiment_label,
        'positive_ratio': round(positive_count / total_count, 3) if total_count > 0 else 0.0,
        'negative_ratio': round(negative_count / total_count, 3) if total_count > 0 else 0.0,
        'neutral_ratio': round(neutral_count / total_count, 3) if total_count > 0 else 0.0,
        'total_discussions': total_count
    }


def get_social_media_sentiment(symbol: str, cookie: str = "") -> Dict[str, Any]:
    """
    获取股票在社交媒体的整体情绪分析
    """
    # 获取雪球讨论数据
    xueqiu_data = get_xueqiu_discussion_sentiment(symbol, cookie)
    
    # 获取微博讨论数据（模拟）
    weibo_data = get_weibo_sentiment(symbol)
    
    # 整合所有平台数据
    all_platforms = [xueqiu_data, weibo_data]
    
    # 计算总体情绪
    overall_sentiment = calculate_overall_sentiment(all_platforms)
    
    return {
        'symbol': symbol,
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'platforms_data': {
            'xueqiu': xueqiu_data,
            'weibo': weibo_data
        },
        'overall_sentiment': overall_sentiment
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("请提供股票代码作为参数")
        exit(1)
    
    symbol = sys.argv[1]
    cookie = sys.argv[2] if len(sys.argv) > 2 else ""
    
    result = get_social_media_sentiment(symbol, cookie)
    
    print(f"股票代码: {symbol}")
    print(f"分析时间: {result['timestamp']}")
    print(f"雪球讨论数: {result['platforms_data']['xueqiu']['count']}")
    print(f"微博讨论数: {result['platforms_data']['weibo']['count']}")
    print(f"总体情绪分数: {result['overall_sentiment']['overall_score']}")
    print(f"情绪标签: {result['overall_sentiment']['sentiment_label']}")
    print(f"正面讨论比例: {result['overall_sentiment']['positive_ratio']}")
    print(f"负面讨论比例: {result['overall_sentiment']['negative_ratio']}")
    print(f"中性讨论比例: {result['overall_sentiment']['neutral_ratio']}")
    print(f"总讨论数: {result['overall_sentiment']['total_discussions']}")