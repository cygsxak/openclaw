# 雪球投资查询技能

这是一个用于查询雪球网投资组合和个股行情的技能，支持查询综合持仓、个股信息、自选股等。

## 功能特性

- 查询综合持仓(PID: 17)的实时行情
- 获取持仓列表和涨跌幅情况
- 支持实时股价查询
- 提供投资组合表现分析
- 格式化表格输出

## 使用方法

### 基本查询
```python
from skills.demo_xueqiu import XueqiuPortfolioAnalyzer

# 创建分析器实例（需要有效的cookie）
analyzer = XueqiuPortfolioAnalyzer("your_cookie_string")

# 查询综合持仓
portfolio_data = analyzer.get_portfolio_quotes(pid=17)
table_output = analyzer.format_portfolio_table(portfolio_data)
print(table_output)
```

### 快速查询
```python
# 查询综合持仓的实时行情
portfolio_data = analyzer.get_portfolio_quotes(pid=17)
```

### 获取持仓列表
```python
# 仅获取持仓股票列表（不含行情）
stocks = analyzer.get_portfolio_stocks(pid=17)
```

### 获取个股行情
```python
# 获取指定股票的实时行情
quotes = analyzer.get_stock_quotes(['SH600036', 'SZ000001'])
```

## API接口

### XueqiuPortfolioAnalyzer类

#### 构造函数
- `__init__(cookie_string=None)`: 初始化分析器，cookie_string为雪球的完整cookie字符串

#### 主要方法
- `get_portfolio_stocks(pid=17)`: 获取指定PID的持仓股票列表
- `get_stock_quotes(symbols)`: 获取股票实时行情
- `get_portfolio_quotes(pid=17)`: 获取指定PID投资组合的持仓股票实时行情
- `format_portfolio_table(portfolio_data)`: 格式化投资组合数据为表格形式
- `analyze_portfolio_performance(portfolio_data)`: 分析投资组合表现

## 配置要求

需要在配置文件中设置有效的雪球COOKIE：

```json
{
  "xueqiu_token": "your_full_cookie_string_here"
}
```

## 注意事项

- 需要有有效的雪球账户COOKIE才能获取数据
- COOKIE有时效性，需要定期更新
- 查询频率不宜过高，避免被雪球限制访问