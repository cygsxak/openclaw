import sys
import os
sys.path.append('/home/codespace/.openclaw/workspace/skills/demo-xueqiu')

from xueqiu_stock_fetcher import XueqiuStockFetcher
import requests
import time

def test_with_full_cookie():
    # 完整的Cookie字符串
    full_cookie = "s=ak16ifihe4; cookiesu=481770170902383; Hm_lvt_1db88642e346389874251b5a1eded6e3=1770170905; HMACCOUNT=926D01031F8F8510; device_id=67dc5b6be5358d3e2d38ada620f024d7; xq_a_token=0f49dbc43aabce03285668102b697d110abf0287; xqat=0f49dbc43aabce03285668102b697d110abf0287; xq_r_token=9fc624b8389d5c731ff388108023728b9a7fd6e7; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOjQ4MzUwMzY0NjIsImlzcyI6InVjIiwiZXhwIjoxNzcxOTM4Nzg3LCJjdG0iOjE3NzAxNzA5Njg1MTYsImNpZCI6ImQ5ZDBuNEFadXAifQ.d1JX1zqGxgyDu6hmcSqMgRlxtIYfEbReelmhGlzcSMblhuANPPqhMij1FiABwaaT4yDwVh4tj2Si1BJKuVYBM2LwgokiClu8nytC_x-Z9SAN7xF0e1enCyabRGRy7B6cAyYM9Gl3buFI8dQweu1fxuibgvlws0lNvuQ1r-P57Ii-f_HDr7Ur6_dh5yaXVa0SmWS58CDHXvAj4XC1mYhJSGV7k-I5O9-UuMEYaGfl8NptNR_78BGk0ctU3LioVqLOY3x3akOSjhENJNcJ3cpXZft1jH7jMerSmXTZS7IiEFfbr0CqnpCtQ05YEYX4wpgk_YnE1drKQjXJNM0FqGexCg; xq_is_login=1; u=4835036462; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1770170974; ssxmod_itna=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OiNDlELeDZDGIQDqx0EbRWWioiKS_lQwYoZRjAEAQP8U22hIQb0AEkyrbvO1kRfyG6MzfDXtAeDU4GnD0=m3ohbDYYjDBYD74G_DDeDixGm7eDSbxD9DGp=qpnbMeDEDYPaxitPOgaOxDLW9jROvDDBIb2d72u4DDX4dnxoN0xOxGYPv=pde1GAwY_=x0tFDBdKDXG=xtl2dYcAuzk7kfbDzdzDtLWzqZ_8lCaTh6mQYvDF4XmKD9e40KKCGqQeXiD4ehteA590xBG=0GPKoXehzi0bDDASriSh5=medhlfyZWPwn5mDA170D9iTBqCIToKDk9iqlGO3hqS2N4br4Rr/iozDKNG4Tbx1GDD; ssxmod_itna2=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OioDicwBKrpBmD03q7YR8Ie58DGXYFd7=452wp=Dkx0qWNKUBh7OwWj4LQRG=wBQSddjbDQOQR3O/4Lq_0=Ob7Lcmd4qNiRY9DL3NlGecCDrDM3O94NtblQVDwx=Exn3sYrrC0fqt_xqw7G8NiitNLjiHaKK3qn5cCjQ5iH9GCX4Hdc==jNPkTHRj8qtoa0INncM9008pTS670tqXSUV3KdL3RR6NR0vxy0cdpBLxPzHuTK08oSH8wKudHpEQtbW=nQn4Q88GVh=c_GZxaBO8Yh1Zu59_Tz8G_3hwOq0kQpgqYjNyfGRDWpMiuRFgfIoCtpohk0xGhvRgvQnQM4AIOz5DQzbt3=qwriFC1ZfC82Q4Lbki7jqtRdwzbv3pWWmIgqdIl84bExcFUxjXQHbSGN=rUu=OibUdHlor7jbVYatRQq0vSfDy21fQq4kGbTN7ezK03o98mQk5fQr61Ch7r7pHtqNqFSS6sms8lv2TvhuaqmTU8noWI/LUawvLTx56wa_657hKmrSzOPAiiQnaRTLqNz4Gj8NOLQ357TI7jxWhkQBFEcWiPG3NpHZDfoigY70gb0axdQB3vhx=uuC2qLsdM4/OUYkS_qYxVQ/Bpb7q5ECbN6_iU4EBN/NqmVfXQDZRj=iS7wUDYbqgk4d3yYZehM0fljig42dNj/tD5Ae3xXTPdhTn5D4s0rQ4/kqb28C3A2YiDD"

    print("使用完整Cookie测试...")
    print(f"Cookie长度: {len(full_cookie)}")
    print()

    fetcher = XueqiuStockFetcher(full_cookie)

    print('正在获取自选股列表...')
    result = fetcher.get_formatted_watchlist()

    print('自选股列表（按涨跌幅倒序排列）：')
    print(result)
    
    print("\n" + "="*60)
    print("额外测试：直接访问API获取数据")
    
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
        'origin': 'https://xueqiu.com',
        'referer': 'https://xueqiu.com/',
        'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
        'cookie': full_cookie
    }

    # 测试获取自选股
    url = 'https://stock.xueqiu.com/v5/stock/portfolio/stock/list.json'
    params = {
        'size': 1000,
        'category': 1,
        'pid': 17
    }

    try:
        response = requests.get(url, headers=headers, params=params, timeout=8)
        print(f'API响应状态码: {response.status_code}')
        if response.status_code == 200:
            data = response.json()
            print('API响应数据:', data)
            
            if 'data' in data and 'stocks' in data['data']:
                stocks = data['data']['stocks']
                print(f'找到 {len(stocks)} 只自选股:')
                if stocks:
                    for i, stock in enumerate(stocks, 1):
                        print(f'{i}. {stock.get("name", "N/A")} ({stock.get("symbol", "N/A")}) - Current: {stock.get("current", "N/A")}, Percent: {stock.get("percent", "N/A")}%')
                else:
                    print("您的自选股列表仍然为空")
            else:
                print('响应中没有找到股票数据')
        else:
            print(f'API请求失败: {response.text}')
    except Exception as e:
        print(f'请求异常: {e}')


if __name__ == "__main__":
    test_with_full_cookie()