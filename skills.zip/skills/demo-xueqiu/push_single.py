#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
单次推送雪球自选股信息到企业微信群
用于cron定时任务调用
"""

import json
import requests
from datetime import datetime
from xueqiu_stock_fetcher import XueqiuStockFetcher

def push_single_update():
    """
    单次推送更新
    """
    # Cookie和webhook URL
    cookie_str = 's=ak16ifihe4; cookiesu=481770170902383; Hm_lvt_1db88642e346389874251b5a1eded6e3=1770170905; HMACCOUNT=926D01031F8F8510; device_id=67dc5b6be5358d3e2d38ada620f024d7; xq_a_token=0f49dbc43aabce03285668102b697d110abf0287; xqat=0f49dbc43aabce03285668102b697d110abf0287; xq_r_token=9fc624b8389d5c731ff388108023728b9a7fd6e7; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOjQ4MzUwMzY0NjIsImlzcyI6InVjIiwiZXhwIjoxNzcxOTM4Nzg3LCJjdG0iOjE3NzAxNzA5Njg1MTYsImNpZCI6ImQ5ZDBuNEFadXAifQ.d1JX1zqGxgyDu6hmcSqMgRlxtIYfEbReelmhGlzcSMblhuANPPqhMij1FiABwaaT4yDwVh4tj2Si1BJKuVYBM2LwgokiClu8nytC_x-Z9SAN7xF0e1enCyabRGRy7B6cAyYM9Gl3buFI8dQweu1fxuibgvlws0lNvuQ1r-P57Ii-f_HDr7Ur6_dh5yaXVa0SmWS58CDHXvAj4XC1mYhJSGV7k-I5O9-UuMEYaGfl8NptNR_78BGk0ctU3LioVqLOY3x3akOSjhENJNcJ3cpXZft1jH7jMerSmXTZS7IiEFfbr0CqnpCtQ05YEYX4wpgk_YnE1drKQjXJNM0FqGexCg; xq_is_login=1; u=4835036462; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1770170974; ssxmod_itna=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OiNDlELeDZDGIQDqx0EbRWWioiKS_lQwYoZRjAEAQP8U22hIQb0AEkyrbvO1kRfyG6MzfDXtAeDU4GnD0=m3ohbDYYjDBYD74G_DDeDixGm7eDSbxD9DGp=qpnbMeDEDYPaxitPOgaOxDLW9jROvDDBIb2d72u4DDX4dnxoN0xOxGYPv=pde1GAwY_=x0tFDBdKDXG=xtl2dYcAuzk7kfbDzdzDtLWzqZ_8lCaTh6mQYvDF4XmKD9e40KKCGqQeXiD4ehteA590xBG=0GPKoXehzi0bDDASriSh5=medhlfyZWPwn5mDA170D9iTBqCIToKDk9iqlGO3hqS2N4br4Rr/iozDKNG4Tbx1GDD; ssxmod_itna2=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OioDicwBKrpBmD03q7YR8Ie58DGXYFd7=452wp=Dkx0qWNKUBh7OwWj4LQRG=wBQSddjbDQOQR3O/4Lq_0=Ob7Lcmd4qNiRY9DL3NlGecCDrDM3O94NtblQVDwx=Exn3sYrrC0fqt_xqw7G8NiitNLjiHaKK3qn5cCjQ5iH9GCX4Hdc==jNPkTHRj8qtoa0INncM9008pTS670tqXSUV3KdL3RR6NR0vxy0cdpBLxPzHuTK08oSH8wKudHpEQtbW=nQn4Q88GVh=c_GZxaBO8Yh1Zu59_Tz8G_3hwOq0kQpgqYjNyfGRDWpMiuRFgfIoCtpohk0xGhvRgvQnQM4AIOz5DQzbt3=qwriFC1ZfC82Q4Lbki7jqtRdwzbv3pWWmIgqdIl84bExcFUxjXQHbSGN=rUu=OibUdHlor7jbVYatRQq0vSfDy21fQq4kGbTN7ezK03o98mQk5fQr61Ch7r7pHtqNqFSS6sms8lv2TvhuaqmTU8noWI/LUawvLTx56wa_657hKmrSzOPAiiQnaRTLqNz4Gj8NOLQ357TI7jxWhkQBFEcWiPG3NpHZDfoigY70gb0axdQB3vhx=uuC2qLsdM4/OUYkS_qYxVQ/Bpb7q5ECbN6_iU4EBN/NqmVfXQDZRj=iS7wUDYbqgk4d3yYZehM0fljig42dNj/tD5Ae3xXTPdhTn5D4s0rQ4/kqb28C3A2YiDD'
    
    webhook_url = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=9e2c1472-9732-442f-85e0-e975671ad639'
    
    # 创建获取器实例
    fetcher = XueqiuStockFetcher(cookie_str)
    
    # 获取自选股列表
    result = fetcher.get_formatted_watchlist()
    
    if "未能获取到自选股列表" in result or "没有找到自选股数据" in result:
        print(f"获取自选股列表失败: {result}")
        return False
    
    # 准备发送到webhook的消息
    headers = {
        'Content-Type': 'application/json'
    }
    
    # 获取当前时间
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 准备发送的消息数据
    data = {
        "msgtype": "text",
        "text": {
            "content": f"【雪球自选股摘要 - {current_time}】\n\n{result}"
        }
    }
    
    try:
        response = requests.post(webhook_url, headers=headers, json=data)
        response.raise_for_status()
        
        result_json = response.json()
        if result_json.get('errcode') == 0:
            print(f"[{current_time}] 股票摘要已成功发送到企业微信群")
            return True
        else:
            print(f"发送失败，错误码: {result_json.get('errcode')}, 错误信息: {result_json.get('errmsg')}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"发送请求时出错: {e}")
        return False

if __name__ == "__main__":
    push_single_update()