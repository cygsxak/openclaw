"""
雪球投资查询技能使用示例
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from xueqiu_portfolio_analyzer import XueqiuPortfolioAnalyzer


def example_usage():
    """
    示例：如何使用雪球投资组合分析技能
    """
    print("雪球投资组合分析技能 - 使用示例")
    print("=" * 50)
    
    # 1. 创建分析器实例
    # 注意：需要提供有效的cookie字符串才能获取真实数据
    analyzer = XueqiuPortfolioAnalyzer()
    
    print("\n1. 查询综合持仓(PID: 17)...")
    
    # 获取持仓的实时行情
    portfolio_data = analyzer.get_portfolio_quotes(pid=17)
    
    if portfolio_data:
        # 格式化显示表格
        table_output = analyzer.format_portfolio_table(portfolio_data)
        print("\n持仓实时行情:")
        print(table_output)
        
        # 分析投资组合表现
        performance_analysis = analyzer.analyze_portfolio_performance(portfolio_data)
        
        print(f"\n投资组合表现分析:")
        print(f"  持仓总数: {performance_analysis['total_stocks']}")
        print(f"  上涨股票: {performance_analysis['positive_count']}")
        print(f"  下跌股票: {performance_analysis['negative_count']}")
        print(f"  平均涨跌幅: {performance_analysis['avg_change']:.2f}%")
        
        if performance_analysis['top_gainer']:
            top_gainer = performance_analysis['top_gainer']
            print(f"  涨幅最大: {top_gainer['name']} ({top_gainer['percent']:+.2f}%)")
        
        if performance_analysis['top_loser']:
            top_loser = performance_analysis['top_loser']
            print(f"  跌幅最大: {top_loser['name']} ({top_loser['percent']:+.2f}%)")
    else:
        print("未能获取到持仓数据，请检查cookie配置")
        print("提示：需要在配置文件中设置有效的雪球COOKIE")


def quick_query_portfolio():
    """
    快速查询综合持仓
    """
    analyzer = XueqiuPortfolioAnalyzer()
    portfolio_data = analyzer.get_portfolio_quotes(pid=17)
    
    if portfolio_data:
        table_output = analyzer.format_portfolio_table(portfolio_data)
        print("综合持仓实时行情:")
        print(table_output)
        return portfolio_data
    else:
        print("未能获取到持仓数据")
        return None


if __name__ == "__main__":
    example_usage()