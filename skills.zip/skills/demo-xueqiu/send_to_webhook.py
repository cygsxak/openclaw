#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
雪球网自选股信息发送到企业微信群webhook
"""

import json
import requests
from xueqiu_stock_fetcher import XueqiuStockFetcher
import sys
import os

def send_to_webhook(stock_summary, webhook_url):
    """
    将股票摘要发送到企业微信群webhook
    
    Args:
        stock_summary: 股票摘要信息
        webhook_url: 企业微信群webhook URL
    """
    headers = {
        'Content-Type': 'application/json'
    }
    
    # 准备发送的消息数据
    data = {
        "msgtype": "text",
        "text": {
            "content": f"【雪球自选股摘要】\n\n{stock_summary}"
        }
    }
    
    try:
        response = requests.post(webhook_url, headers=headers, json=data)
        response.raise_for_status()
        
        result = response.json()
        if result.get('errcode') == 0:
            print("✅ 股票摘要已成功发送到企业微信群")
            return True
        else:
            print(f"❌ 发送失败，错误码: {result.get('errcode')}, 错误信息: {result.get('errmsg')}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ 发送请求时出错: {e}")
        return False

def get_and_send_watchlist(cookie_str, webhook_url):
    """
    获取自选股列表并发送到webhook
    
    Args:
        cookie_str: 雪球网Cookie字符串
        webhook_url: 企业微信群webhook URL
    """
    print("🚀 开始获取雪球自选股列表...")
    
    # 创建股票获取器实例
    fetcher = XueqiuStockFetcher(cookie_str)
    
    # 获取格式化的自选股列表
    result = fetcher.get_formatted_watchlist()
    
    if "未能获取到自选股列表" in result or "没有找到自选股数据" in result:
        print(f"⚠️  {result}")
        return False
    
    print("\n📊 获取到的自选股列表：")
    print(result)
    
    print(f"\n📤 正在发送到企业微信群...")
    success = send_to_webhook(result, webhook_url)
    
    return success

def main():
    """
    主函数
    """
    print("雪球网自选股信息发送工具")
    print("="*40)
    
    # 从命令行参数获取webhook URL（或者在这里直接定义）
    if len(sys.argv) > 1:
        webhook_url = sys.argv[1]
    else:
        # 如果没有提供命令行参数，则使用默认URL
        webhook_url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=9e2c1472-9732-442f-85e0-e975671ad639"
    
    # 提示用户输入Cookie
    print(f"请提供雪球网的完整Cookie字符串：")
    cookie_str = input().strip()
    
    if not cookie_str:
        print("❌ 未输入Cookie，程序退出。")
        return False
    
    # 执行获取并发送操作
    success = get_and_send_watchlist(cookie_str, webhook_url)
    
    if success:
        print("\n🎉 任务完成！自选股信息已成功发送到企业微信群。")
    else:
        print("\n💥 任务失败！请检查Cookie是否有效或网络连接是否正常。")
    
    return success

if __name__ == "__main__":
    main()