import requests
import json
from typing import Dict, List, Optional
import os


class XueqiuPortfolioAnalyzer:
    """
    雪球投资组合分析器
    """
    
    def __init__(self, cookie_string: str = None):
        """
        初始化分析器
        :param cookie_string: 雪球的完整cookie字符串，如果未提供则尝试从配置文件读取
        """
        if cookie_string:
            self.cookie_string = cookie_string
        else:
            self.cookie_string = self._get_cookie_from_config()
        
        self.headers = {
            'Cookie': self.cookie_string,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': 'https://xueqiu.com/',
            'Accept': 'application/json, text/plain, */*'
        }
    
    def _get_cookie_from_config(self) -> str:
        """从配置文件获取cookie"""
        config_path = '/home/codespace/.openclaw/workspace/config.json'
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    # 从完整cookie字符串中提取xq_a_token
                    full_cookie = config.get('xueqiu_token', '')
                    if full_cookie:
                        return full_cookie
            except:
                pass
        return ""
    
    def get_portfolio_stocks(self, pid: int = 17) -> List[Dict]:
        """
        获取指定PID的持仓股票列表
        :param pid: 投资组合ID，默认为17（综合持仓）
        :return: 股票列表
        """
        url = "https://stock.xueqiu.com/v5/stock/portfolio/stock/list.json"
        params = {
            'size': 1000,
            'category': 1,
            'pid': pid
        }
        
        try:
            response = requests.get(url, headers=self.headers, params=params)
            if response.status_code == 200:
                data = response.json()
                return data.get('data', {}).get('stocks', [])
            else:
                print(f"获取持仓列表失败: {response.status_code}")
                return []
        except Exception as e:
            print(f"获取持仓列表时发生错误: {str(e)}")
            return []
    
    def get_stock_quotes(self, symbols: List[str]) -> List[Dict]:
        """
        获取股票实时行情
        :param symbols: 股票代码列表
        :return: 行情数据列表
        """
        if not symbols:
            return []
        
        symbols_str = ','.join(symbols)
        url = "https://stock.xueqiu.com/v5/stock/batch/quote.json"
        params = {
            'symbol': symbols_str
        }
        
        try:
            response = requests.get(url, headers=self.headers, params=params)
            if response.status_code == 200:
                data = response.json()
                return data.get('data', {}).get('items', [])
            else:
                print(f"获取行情数据失败: {response.status_code}")
                return []
        except Exception as e:
            print(f"获取行情数据时发生错误: {str(e)}")
            return []
    
    def get_portfolio_quotes(self, pid: int = 17) -> List[Dict]:
        """
        获取指定PID投资组合的持仓股票实时行情
        :param pid: 投资组合ID，默认为17（综合持仓）
        :return: 包含股票信息和行情的列表
        """
        # 获取持仓列表
        stocks = self.get_portfolio_stocks(pid)
        if not stocks:
            return []
        
        # 提取股票代码
        symbols = [stock['symbol'] for stock in stocks]
        
        # 获取实时行情
        quotes = self.get_stock_quotes(symbols)
        
        # 合并持仓信息和行情信息
        result = []
        quote_dict = {item.get('quote', {}).get('symbol', ''): item.get('quote', {}) 
                      for item in quotes if item.get('quote')}
        
        for stock in stocks:
            symbol = stock['symbol']
            quote_info = quote_dict.get(symbol, {})
            
            combined_info = {
                'name': stock['name'],
                'symbol': stock['symbol'],
                'current': quote_info.get('current', 0),
                'percent': quote_info.get('percent', 0),
                'chg': quote_info.get('chg', 0),
                'type': stock['type'],
                'marketplace': stock['marketplace'],
                'created': stock.get('created', 0),
                'watched': stock.get('watched', 0)
            }
            result.append(combined_info)
        
        return result
    
    def format_portfolio_table(self, portfolio_data: List[Dict]) -> str:
        """
        格式化投资组合数据为表格形式
        :param portfolio_data: 投资组合数据
        :return: 格式化的表格字符串
        """
        if not portfolio_data:
            return "未获取到持仓数据"
        
        # 计算表头长度
        table_lines = []
        table_lines.append(f"{'股票名称':<12} {'代码':<12} {'当前价':<10} {'涨跌幅':<10} {'涨跌额':<10}")
        table_lines.append("-" * 60)
        
        for item in portfolio_data:
            name = item['name'][:10]  # 截取前10个字符
            symbol = item['symbol']
            current = f"{item['current']:.2f}"
            percent = f"{item['percent']:+.2f}%"
            chg = f"{item['chg']:+.2f}"
            
            table_lines.append(f"{name:<12} {symbol:<12} {current:<10} {percent:<10} {chg:<10}")
        
        table_lines.append("-" * 60)
        
        # 添加统计信息
        up_count = sum(1 for item in portfolio_data if item['percent'] > 0)
        down_count = sum(1 for item in portfolio_data if item['percent'] < 0)
        flat_count = len(portfolio_data) - up_count - down_count
        
        table_lines.append(f"上涨: {up_count} | 下跌: {down_count} | 平盘: {flat_count}")
        
        return '\n'.join(table_lines)
    
    def analyze_portfolio_performance(self, portfolio_data: List[Dict]) -> Dict:
        """
        分析投资组合表现
        :param portfolio_data: 投资组合数据
        :return: 分析结果
        """
        if not portfolio_data:
            return {}
        
        total_stocks = len(portfolio_data)
        positive_count = sum(1 for item in portfolio_data if item['percent'] > 0)
        negative_count = sum(1 for item in portfolio_data if item['percent'] < 0)
        
        # 计算平均涨跌幅
        total_change = sum(item['percent'] for item in portfolio_data)
        avg_change = total_change / total_stocks if total_stocks > 0 else 0
        
        # 找出涨幅最大和跌幅最大的股票
        top_gainer = max(portfolio_data, key=lambda x: x['percent']) if portfolio_data else None
        top_loser = min(portfolio_data, key=lambda x: x['percent']) if portfolio_data else None
        
        analysis = {
            'total_stocks': total_stocks,
            'positive_count': positive_count,
            'negative_count': negative_count,
            'avg_change': avg_change,
            'top_gainer': top_gainer,
            'top_loser': top_loser
        }
        
        return analysis


def main():
    """
    示例用法
    """
    # 注意：这里需要提供有效的cookie字符串
    # cookie_string = "your_full_cookie_string_here"
    # analyzer = XueqiuPortfolioAnalyzer(cookie_string)
    
    # 由于无法在此处提供真实的cookie，以下代码仅作演示
    print("雪球投资组合分析器初始化完成")
    print("请使用有效的cookie字符串初始化分析器")


if __name__ == "__main__":
    main()