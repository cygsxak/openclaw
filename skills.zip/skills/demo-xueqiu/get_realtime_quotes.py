import sys
import os
sys.path.append('/home/codespace/.openclaw/workspace/skills/demo-xueqiu')

import requests
import time

def get_realtime_quotes():
    # 完整的Cookie字符串
    full_cookie = 's=ak16ifihe4; cookiesu=481770170902383; Hm_lvt_1db88642e346389874251b5a1eded6e3=1770170905; HMACCOUNT=926D01031F8F8510; device_id=67dc5b6be5358d3e2d38ada620f024d7; xq_a_token=0f49dbc43aabce03285668102b697d110abf0287; xqat=0f49dbc43aabce03285668102b697d110abf0287; xq_r_token=9fc624b8389d5c731ff388108023728b9a7fd6e7; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOjQ4MzUwMzY0NjIsImlzcyI6InVjIiwiZXhwIjoxNzcxOTM4Nzg3LCJjdG0iOjE3NzAxNzA5Njg1MTYsImNpZCI6ImQ5ZDBuNEFadXAifQ.d1JX1zqGxgyDu6hmcSqMgRlxtIYfEbReelmhGlzcSMblhuANPPqhMij1FiABwaaT4yDwVh4tj2Si1BJKuVYBM2LwgokiClu8nytC_x-Z9SAN7xF0e1enCyabRGRy7B6cAyYM9Gl3buFI8dQweu1fxuibgvlws0lNvuQ1r-P57Ii-f_HDr7Ur6_dh5yaXVa0SmWS58CDHXvAj4XC1mYhJSGV7k-I5O9-UuMEYaGfl8NptNR_78BGk0ctU3LioVqLOY3x3akOSjhENJNcJ3cpXZft1jH7jMerSmXTZS7IiEFfbr0CqnpCtQ05YEYX4wpgk_YnE1drKQjXJNM0FqGexCg; xq_is_login=1; u=4835036462; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1770170974; ssxmod_itna=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OiNDlELeDZDGIQDqx0EbRWWioiKS_lQwYoZRjAEAQP8U22hIQb0AEkyrbvO1kRfyG6MzfDXtAeDU4GnD0=m3ohbDYYjDBYD74G_DDeDixGm7eDSbxD9DGp=qpnbMeDEDYPaxitPOgaOxDLW9jROvDDBIb2d72u4DDX4dnxoN0xOxGYPv=pde1GAwY_=x0tFDBdKDXG=xtl2dYcAuzk7kfbDzdzDtLWzqZ_8lCaTh6mQYvDF4XmKD9e40KKCGqQeXiD4ehteA590xBG=0GPKoXehzi0bDDASriSh5=medhlfyZWPwn5mDA170D9iTBqCIToKDk9iqlGO3hqS2N4br4Rr/iozDKNG4Tbx1GDD; ssxmod_itna2=1-QuDQGKDv4fxR2x_xeFnxKqYq0I18qYK0=TDzxC5iOGDuxiK08D6mxBRi1ewkOmA7xsPCY3RhxOS6OioDicwBKrpBmD03q7YR8Ie58DGXYFd7=452wp=Dkx0qWNKUBh7OwWj4LQRG=wBQSddjbDQOQR3O/4Lq_0=Ob7Lcmd4qNiRY9DL3NlGecCDrDM3O94NtblQVDwx=Exn3sYrrC0fqt_xqw7G8NiitNLjiHaKK3qn5cCjQ5iH9GCX4Hdc==jNPkTHRj8qtoa0INncM9008pTS670tqXSUV3KdL3RR6NR0vxy0cdpBLxPzHuTK08oSH8wKudHpEQtbW=nQn4Q88GVh=c_GZxaBO8Yh1Zu59_Tz8G_3hwOq0kQpgqYjNyfGRDWpMiuRFgfIoCtpohk0xGhvRgvQnQM4AIOz5DQzbt3=qwriFC1ZfC82Q4Lbki7jqtRdwzbv3pWWmIgqdIl84bExcFUxjXQHbSGN=rUu=OibUdHlor7jbVYatRQq0vSfDy21fQq4kGbTN7ezK03o98mQk5fQr61Ch7r7pHtqNqFSS6sms8lv2TvhuaqmTU8noWI/LUawvLTx56wa_657hKmrSzOPAiiQnaRTLqNz4Gj8NOLQ357TI7jxWhkQBFEcWiPG3NpHZDfoigY70gb0axdQB3vhx=uuC2qLsdM4/OUYkS_qYxVQ/Bpb7q5ECbN6_iU4EBN/NqmVfXQDZRj=iS7wUDYbqgk4d3yYZehM0fljig42dNj/tD5Ae3xXTPdhTn5D4s0rQ4/kqb28C3A2YiDD'

    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
        'origin': 'https://xueqiu.com',
        'referer': 'https://xueqiu.com/',
        'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
        'cookie': full_cookie
    }

    # 首先获取自选股列表
    url = 'https://stock.xueqiu.com/v5/stock/portfolio/stock/list.json'
    params = {
        'size': 1000,
        'category': 1,
        'pid': 17
    }

    try:
        response = requests.get(url, headers=headers, params=params, timeout=8)
        if response.status_code == 200:
            data = response.json()
            if 'data' in data and 'stocks' in data['data']:
                stocks = data['data']['stocks']
                print(f'您共有 {len(stocks)} 只自选股:')
                print(f'{"排名":<4} {"股票名称":<15} {"代码":<15} {"涨跌幅":<10} {"当前价格"}')
                print('-' * 70)
                
                # 提取股票代码用于批量查询
                symbols = [stock['symbol'] for stock in stocks]
                print(f'\n提取的股票代码: {symbols}')
                
                # 批量获取股票实时数据
                if symbols:
                    symbol_str = ','.join(symbols)
                    quote_url = 'https://stock.xueqiu.com/v5/stock/batch/quote.json'
                    quote_params = {
                        'symbol': symbol_str,
                        'extend': 'detail',
                        'is_delay_hk': 'true'
                    }
                    
                    print('\n正在获取实时行情数据...')
                    quote_response = requests.get(quote_url, headers=headers, params=quote_params, timeout=8)
                    
                    if quote_response.status_code == 200:
                        quote_data = quote_response.json()
                        if 'data' in quote_data and 'items' in quote_data['data']:
                            # 创建股票数据字典以便匹配
                            quote_dict = {}
                            for item in quote_data['data']['items']:
                                if 'quote' in item:
                                    quote_info = item['quote']
                                    symbol = quote_info.get('symbol')
                                    if symbol:
                                        quote_dict[symbol] = quote_info
                            
                            # 按涨跌幅排序
                            sorted_stocks = sorted(stocks, key=lambda x: quote_dict.get(x['symbol'], {}).get('percent', 0), reverse=True)
                            
                            for i, stock in enumerate(sorted_stocks, 1):
                                symbol = stock['symbol']
                                name = stock['name']
                                
                                # 获取实时数据
                                quote_info = quote_dict.get(symbol, {})
                                current_price = quote_info.get('current', 'N/A')
                                percent_change = quote_info.get('percent', 'N/A')
                                
                                if isinstance(percent_change, float):
                                    percent_str = f'{percent_change:+.2f}%'
                                elif isinstance(percent_change, (int, str)):
                                    try:
                                        percent_str = f'{float(percent_change):+.2f}%'
                                    except ValueError:
                                        percent_str = 'N/A'
                                else:
                                    percent_str = 'N/A'
                                
                                print(f'{i:<4} {name:<15} {symbol:<15} {percent_str:<10} {current_price}')
                        else:
                            print('未能获取到实时行情数据')
                            print('响应内容:', quote_data)
                    else:
                        print(f'获取实时行情失败: {quote_response.status_code}, {quote_response.text}')
            else:
                print('未能获取到自选股数据')
        else:
            print(f'获取自选股列表失败: {response.status_code}, {response.text}')
    except Exception as e:
        print(f'请求异常: {e}')

if __name__ == "__main__":
    get_realtime_quotes()