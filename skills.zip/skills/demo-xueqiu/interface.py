"""
雪球投资查询技能接口
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from xueqiu_portfolio_analyzer import XueqiuPortfolioAnalyzer


def query_portfolio(pid: int = 17) -> str:
    """
    查询指定PID的投资组合
    :param pid: 投资组合ID，默认为17（综合持仓）
    :return: 格式化的持仓信息
    """
    analyzer = XueqiuPortfolioAnalyzer()
    portfolio_data = analyzer.get_portfolio_quotes(pid)
    
    if portfolio_data:
        table_output = analyzer.format_portfolio_table(portfolio_data)
        return f"PID {pid} 持仓实时行情:\n{table_output}"
    else:
        return f"未能获取PID {pid}的持仓数据，请检查cookie配置"


def query_portfolio_performance(pid: int = 17) -> str:
    """
    查询指定PID投资组合的表现分析
    :param pid: 投资组合ID，默认为17（综合持仓）
    :return: 格式化的表现分析
    """
    analyzer = XueqiuPortfolioAnalyzer()
    portfolio_data = analyzer.get_portfolio_quotes(pid)
    
    if portfolio_data:
        analysis = analyzer.analyze_portfolio_performance(portfolio_data)
        
        result = f"PID {pid} 投资组合表现分析:\n"
        result += f"  持仓总数: {analysis['total_stocks']}\n"
        result += f"  上涨股票: {analysis['positive_count']}\n"
        result += f"  下跌股票: {analysis['negative_count']}\n"
        result += f"  平均涨跌幅: {analysis['avg_change']:.2f}%\n"
        
        if analysis['top_gainer']:
            top_gainer = analysis['top_gainer']
            result += f"  涨幅最大: {top_gainer['name']} ({top_gainer['percent']:+.2f}%)\n"
        
        if analysis['top_loser']:
            top_loser = analysis['top_loser']
            result += f"  跌幅最大: {top_loser['name']} ({top_loser['percent']:+.2f}%)\n"
        
        return result
    else:
        return f"未能获取PID {pid}的表现分析数据，请检查cookie配置"


def get_top_performer(pid: int = 17) -> str:
    """
    获取指定PID投资组合中表现最好的股票
    :param pid: 投资组合ID，默认为17（综合持仓）
    :return: 表现最好股票的信息
    """
    analyzer = XueqiuPortfolioAnalyzer()
    portfolio_data = analyzer.get_portfolio_quotes(pid)
    
    if portfolio_data:
        top_gainer = max(portfolio_data, key=lambda x: x['percent'])
        return f"PID {pid} 表现最好的股票: {top_gainer['name']} ({top_gainer['symbol']}) 涨幅: {top_gainer['percent']:+.2f}%"
    else:
        return f"未能获取PID {pid}的数据，请检查cookie配置"


def get_worst_performer(pid: int = 17) -> str:
    """
    获取指定PID投资组合中表现最差的股票
    :param pid: 投资组合ID，默认为17（综合持仓）
    :return: 表现最差股票的信息
    """
    analyzer = XueqiuPortfolioAnalyzer()
    portfolio_data = analyzer.get_portfolio_quotes(pid)
    
    if portfolio_data:
        top_loser = min(portfolio_data, key=lambda x: x['percent'])
        return f"PID {pid} 表现最差的股票: {top_loser['name']} ({top_loser['symbol']}) 涨幅: {top_loser['percent']:+.2f}%"
    else:
        return f"未能获取PID {pid}的数据，请检查cookie配置"


# 便捷函数
def quick_check() -> str:
    """
    快速检查综合持仓（PID 17）
    :return: 综合持仓的表格和简要分析
    """
    result = query_portfolio(17)
    result += "\n\n"
    result += query_portfolio_performance(17)
    return result