"""
雪球投资查询技能 - 初始化文件
"""
from .xueqiu_portfolio_analyzer import XueqiuPortfolioAnalyzer

__all__ = ['XueqiuPortfolioAnalyzer']

def get_portfolio_analyzer():
    """
    获取雪球投资组合分析器实例
    """
    return XueqiuPortfolioAnalyzer()