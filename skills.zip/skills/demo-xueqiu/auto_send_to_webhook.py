#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
自动化发送雪球自选股到企业微信群webhook
此脚本会获取用户的自选股并自动发送到指定webhook
"""

import json
import requests
from xueqiu_stock_fetcher import XueqiuStockFetcher
import os

def send_stock_summary_to_webhook(cookie_file_path=None, cookie_str=None, webhook_url=None):
    """
    发送股票摘要到webhook的主函数
    
    Args:
        cookie_file_path: 存储Cookie的文件路径（可选）
        cookie_str: 直接传入的Cookie字符串（可选）
        webhook_url: 企业微信群webhook URL
    """
    
    # 默认webhook URL
    if not webhook_url:
        webhook_url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=9e2c1472-9732-442f-85e0-e975671ad639"
    
    # 获取Cookie
    if cookie_str:
        final_cookie = cookie_str
    elif cookie_file_path and os.path.exists(cookie_file_path):
        with open(cookie_file_path, 'r', encoding='utf-8') as f:
            final_cookie = f.read().strip()
    else:
        print("❌ 未提供有效的Cookie信息")
        return False
    
    print("🚀 正在获取雪球自选股列表...")
    
    # 创建股票获取器实例
    fetcher = XueqiuStockFetcher(final_cookie)
    
    # 获取格式化的自选股列表
    result = fetcher.get_formatted_watchlist()
    
    if "未能获取到自选股列表" in result or "没有找到自选股数据" in result:
        print(f"⚠️  {result}")
        return False
    
    print("\n📊 获取到的自选股列表：")
    print(result)
    
    # 准备发送到webhook的消息
    headers = {
        'Content-Type': 'application/json'
    }
    
    # 准备发送的消息数据
    data = {
        "msgtype": "text",
        "text": {
            "content": f"【雪球自选股摘要 - {requests.get('http://worldtimeapi.org/api/timezone/UTC').json()['datetime'][:19]}】\n\n{result}"
        }
    }
    
    try:
        print(f"\n📤 正在发送到企业微信群...")
        response = requests.post(webhook_url, headers=headers, json=data)
        response.raise_for_status()
        
        result_json = response.json()
        if result_json.get('errcode') == 0:
            print("✅ 股票摘要已成功发送到企业微信群")
            return True
        else:
            print(f"❌ 发送失败，错误码: {result_json.get('errcode')}, 错误信息: {result_json.get('errmsg')}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ 发送请求时出错: {e}")
        return False

# 如果直接运行此脚本，使用默认配置
if __name__ == "__main__":
    print("自动化雪球自选股发送工具")
    print("="*40)
    
    # 这里可以配置实际的Cookie和webhook URL
    # 注意：出于安全考虑，不应在代码中硬编码真实Cookie
    success = send_stock_summary_to_webhook(
        # cookie_str="your_actual_cookie_here",  # 不要在代码中存储真实Cookie
        webhook_url="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=9e2c1472-9732-442f-85e0-e975671ad639"
    )
    
    if success:
        print("\n🎉 任务完成！")
    else:
        print("\n💡 提示：需要提供有效的雪球网Cookie才能获取您的自选股信息。")