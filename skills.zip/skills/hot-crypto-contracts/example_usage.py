"""
虚拟币合约交易信号分析技能使用示例
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from crypto_contract_analyzer import CryptoContractAnalyzer

def example_usage():
    """
    示例：如何使用虚拟币合约分析技能
    """
    print("虚拟币合约交易信号分析技能 - 使用示例")
    print("=" * 50)
    
    # 1. 创建分析器实例
    analyzer = CryptoContractAnalyzer()
    
    # 2. 获取强势币种清单
    print("\n1. 获取强势虚拟币合约清单...")
    print("注意：完整分析可能需要几分钟时间")
    
    # 为了演示目的，我们只分析几个主要币种
    major_symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT']
    
    strong_candidates = []
    for symbol in major_symbols:
        df = analyzer.get_kline_data(symbol, '15m', 100)
        if not df.empty:
            analysis = analyzer.analyze_technical_indicators(df, symbol)
            if analysis:
                # 根据特定条件筛选强势币种
                if (analysis['rsi'] < 30 or analysis['rsi'] > 70 or  # 极端情绪
                    abs(analysis['change_percent_24h']) > 5 or      # 大幅波动
                    analysis['pro_indicators']['ema_trend'] != '震荡'):  # 明确趋势
                    strong_candidates.append(analysis)
    
    # 3. 显示分析结果
    print(f"\n2. 发现 {len(strong_candidates)} 个值得关注的合约:")
    for coin in strong_candidates:
        print(f"\n--- {coin['symbol']} ---")
        print(f"价格: {coin['price']}")
        print(f"24小时变化: {coin['change_percent_24h']}%")
        print(f"RSI: {coin['rsi']}")
        print(f"趋势: {coin['pro_indicators']['ema_trend']}")
        print(f"价格位置: {coin['pro_indicators']['price_pos']}")
        print(f"成交量状态: {coin['volume_status']}")
        print(f"波动率: {coin['volatility']}")
        print(f"高点距离: {coin['high_distance_pct']}%")
        
        # 提供建议
        advice = generate_trading_advice(coin)
        print(f"建议: {advice}")
    
    # 4. 如果需要完整分析（耗时较长），取消下面的注释
    # print("\n3. 执行完整强势币种分析...")
    # all_strong_coins = analyzer.get_strong_coins(min_change_24h=2.0)
    # print(f"发现 {len(all_strong_coins)} 个强势币种")


def generate_trading_advice(analysis):
    """
    根据分析结果生成交易建议
    """
    symbol = analysis['symbol']
    rsi = analysis['rsi']
    trend = analysis['pro_indicators']['ema_trend']
    change_24h = analysis['change_percent_24h']
    price_pos = analysis['pro_indicators']['price_pos']
    
    if trend == "强多头 (Bullish)" and 30 < rsi < 70:
        return "多头趋势良好，RSI位置合理，可考虑做多"
    elif trend == "强空头 (Bearish)" and 30 < rsi < 70:
        return "空头趋势明显，RSI位置合理，可考虑做空"
    elif rsi < 30:
        return "超卖区域，可能反弹，谨慎做多"
    elif rsi > 70:
        return "超买区域，可能回调，谨慎做空"
    elif change_24h > 10:
        return "24小时大幅上涨，注意获利了结风险"
    elif change_24h < -10:
        return "24小时大幅下跌，等待企稳信号"
    else:
        return "市场震荡，观望为宜"
    

if __name__ == "__main__":
    example_usage()