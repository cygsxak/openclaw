from crypto_contract_analyzer import CryptoContractAnalyzer

def demo_analysis():
    """
    演示分析功能 - 只分析几个主要币种以节省时间
    """
    analyzer = CryptoContractAnalyzer()
    
    # 选择主要币种进行快速演示
    major_symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT']
    
    print("虚拟币合约交易信号分析 - 演示版")
    print("=" * 50)
    
    results = []
    for symbol in major_symbols:
        print(f"正在分析 {symbol}...")
        
        # 获取K线数据
        df = analyzer.get_kline_data(symbol, '15m', 100)
        
        if not df.empty:
            # 分析技术指标
            analysis = analyzer.analyze_technical_indicators(df, symbol)
            
            if analysis:
                results.append(analysis)
                print(f"  ✓ {symbol} 分析完成")
                print(f"    价格: {analysis['price']}")
                print(f"    24h变化: {analysis['change_percent_24h']}%")
                print(f"    RSI: {analysis['rsi']}")
                print(f"    趋势: {analysis['pro_indicators']['ema_trend']}")
                print(f"    位置: {analysis['pro_indicators']['price_pos']}")
                print(f"    成交量: {analysis['volume_status']}")
                print()
        else:
            print(f"  ✗ 无法获取 {symbol} 的数据")
    
    # 根据24小时变化排序
    sorted_results = sorted(results, key=lambda x: x['change_percent_24h'], reverse=True)
    
    print("按24小时涨幅排序的结果:")
    print("-" * 50)
    for i, result in enumerate(sorted_results[:5]):  # 显示前5名
        print(f"{i+1}. {result['symbol']}")
        print(f"   价格: {result['price']}")
        print(f"   24h变化: {result['change_percent_24h']}%")
        print(f"   RSI: {result['rsi']}")
        print(f"   趋势: {result['pro_indicators']['ema_trend']}")
        print(f"   位置: {result['pro_indicators']['price_pos']}")
        print(f"   量能: {result['volume_status']}")
        print()
    
    return sorted_results

if __name__ == "__main__":
    demo_analysis()