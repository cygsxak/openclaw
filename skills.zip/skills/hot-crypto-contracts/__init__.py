"""
Hot Crypto Contracts Skill - Virtual currency contract trading signal analyzer
"""
from .crypto_contract_analyzer import CryptoContractAnalyzer

__all__ = ['CryptoContractAnalyzer']

def analyze_hot_contracts():
    """
    主要接口函数：分析热门虚拟币合约
    """
    analyzer = CryptoContractAnalyzer()
    return analyzer.get_strong_coins()

def get_top_performers(limit=10):
    """
    获取表现最好的合约
    """
    analyzer = CryptoContractAnalyzer()
    strong_coins = analyzer.get_strong_coins()
    return strong_coins[:limit]