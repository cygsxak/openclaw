import pandas as pd
import requests
import numpy as np
from typing import Dict, List, Optional
import json
from datetime import datetime


class CryptoContractAnalyzer:
    """
    Virtual currency contract trading signal analyzer
    """
    
    def __init__(self):
        self.base_url = "https://fapi.binance.com"  # Futures API
        
    def get_exchange_info(self) -> List[str]:
        """
        Step 1: Get contract information from Binance API
        """
        try:
            response = requests.get(f"{self.base_url}/fapi/v1/exchangeInfo", timeout=10)
            response.raise_for_status()
            data = response.json()
            
            # Filter USDT perpetual futures
            symbols = [
                symbol['symbol'] 
                for symbol in data['symbols'] 
                if symbol['quoteAsset'] == 'USDT' and symbol['contractType'] == 'PERPETUAL'
            ]
            
            return symbols
        except Exception as e:
            print(f"Error fetching exchange info: {e}")
            return []
    
    def get_kline_data(self, symbol: str, interval: str = "15m", limit: int = 100) -> pd.DataFrame:
        """
        Step 2: Get K-line data (15m timeframe)
        """
        try:
            params = {
                'symbol': symbol,
                'interval': interval,
                'limit': limit
            }
            response = requests.get(f"{self.base_url}/fapi/v1/klines", params=params, timeout=10)
            response.raise_for_status()
            
            klines = response.json()
            
            # Convert to DataFrame
            df = pd.DataFrame(
                klines, 
                columns=[
                    'timestamp', 'open', 'high', 'low', 'close', 'volume',
                    'close_time', 'quote_asset_volume', 'num_trades',
                    'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
                ]
            )
            
            # Convert to numeric types
            for col in ['open', 'high', 'low', 'close', 'volume', 'quote_asset_volume']:
                df[col] = pd.to_numeric(df[col])
                
            # Calculate additional columns
            df['quote_vol'] = df['close'] * df['volume']
            
            return df
        except Exception as e:
            print(f"Error fetching kline data for {symbol}: {e}")
            return pd.DataFrame()
    
    def analyze_technical_indicators(self, df: pd.DataFrame, symbol: str) -> Dict:
        """
        Step 3: Analyze technical indicators
        """
        if df.empty or len(df) < 100:
            return {}
            
        closes = df['close']
        highs = df['high']
        lows = df['low']
        volumes = df['volume']
        current_price = float(closes.iloc[-1])
        
        # 1. EMAs (7, 25, 99) for Trend
        ema7 = float(closes.ewm(span=7, adjust=False).mean().iloc[-1])
        ema25 = float(closes.ewm(span=25, adjust=False).mean().iloc[-1])
        ema99 = float(closes.ewm(span=99, adjust=False).mean().iloc[-1])
        
        # Trend determination
        ema_trend = "震荡"
        if ema7 > ema25 > ema99:
            ema_trend = "强多头 (Bullish)"
        elif ema7 < ema25 < ema99:
            ema_trend = "强空头 (Bearish)"
        
        # Price position relative to EMAs
        price_pos = "混杂"
        if current_price > ema7 and current_price > ema25 and current_price > ema99:
            price_pos = "站上所有均线 (Strong)"
        elif current_price < ema7 and current_price < ema25 and current_price < ema99:
            price_pos = "跌破所有均线 (Weak)"
        
        # 2. RSI (14)
        delta = closes.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss.replace(0, 1e-9)
        rsi_val = 100 - (100 / (1 + rs))
        rsi_val = float(rsi_val.iloc[-1])
        
        # 3. MACD (12, 26, 9)
        ema12 = closes.ewm(span=12, adjust=False).mean()
        ema26 = closes.ewm(span=26, adjust=False).mean()
        macd_line = ema12 - ema26
        signal_line = macd_line.ewm(span=9, adjust=False).mean()
        macd_hist = macd_line - signal_line
        
        # 4. Bollinger Bands (20, 2)
        sma20 = closes.rolling(window=20).mean()
        std20 = closes.rolling(window=20).std()
        bb_upper = sma20 + 2 * std20
        bb_lower = sma20 - 2 * std20
        bb_bandwidth = (bb_upper - bb_lower) / sma20
        
        # 5. ATR (14)
        high_low = df['high'] - df['low']
        high_close = (df['high'] - df['close'].shift()).abs()
        low_close = (df['low'] - df['close'].shift()).abs()
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr_val = float(tr.rolling(window=14).mean().iloc[-1])
        
        # 6. Volatility (Std Dev of Returns)
        volatility = float(closes.pct_change().std())
        
        # 7. High Distance (100 period)
        max_high_100 = float(df['high'].tail(100).max())
        high_dist = float(((max_high_100 - current_price) / max_high_100 * 100) if max_high_100 > 0 else 0)
        
        # 8. Legacy Strong Coin Logic Support (EMA 3, 9, 120)
        ema3_legacy = float(closes.ewm(span=3, adjust=False).mean().iloc[-1])
        ema9_legacy = float(closes.ewm(span=9, adjust=False).mean().iloc[-1])
        ema120_legacy = float(closes.ewm(span=120, adjust=False).mean().iloc[-1])
        above_all_emas_legacy = bool(current_price > ema3_legacy and current_price > ema9_legacy and current_price > ema120_legacy)
        
        # Consecutive Bullish (Last 3)
        last_3 = df.tail(3)
        consecutive_bullish = bool(all(row['close'] > row['open'] for _, row in last_3.iterrows()))
        
        # Get 24hr ticker data
        ticker_params = {'symbol': symbol}
        try:
            ticker_response = requests.get(f"{self.base_url}/fapi/v1/ticker/24hr", params=ticker_params, timeout=10)
            ticker_data = ticker_response.json()
            day_change_percent = float(ticker_data['priceChangePercent'])
            day_quote_volume = float(ticker_data.get('quoteVolume', 0))
        except Exception:
            day_change_percent = 0
            day_quote_volume = 0
        
        # Strategy Match (Legacy)
        strategy_match = bool(
            day_change_percent > 15 and 
            day_quote_volume > 30_000_000 and 
            above_all_emas_legacy and 
            consecutive_bullish and 
            high_dist > 10.0
        )
        
        # Volume Status
        avg_vol = df['quote_vol'].tail(20).mean()
        curr_vol = df['quote_vol'].iloc[-1]
        if curr_vol > avg_vol * 1.5:
            volume_status = "放量"
        elif curr_vol < avg_vol * 0.5:
            volume_status = "缩量"
        else:
            volume_status = "正常"
        
        # Period Change (100 candles)
        first_price = df['open'].iloc[-100] if len(df) >= 100 else df['open'].iloc[0]
        change_percent_period = ((current_price - first_price) / first_price * 100)
        
        # Return comprehensive analysis
        return {
            "symbol": symbol,
            "price": round(current_price, 6),
            "change_percent_period": round(change_percent_period, 2),
            "change_percent_24h": round(day_change_percent, 2),
            "volume_status": volume_status,
            "day_quote_volume_m": round(day_quote_volume / 1000000, 2),
            "volatility": round(volatility, 4),
            "rsi": round(rsi_val, 2),
            "high_distance_pct": round(high_dist, 2),
            "fear_greed_index": None,  # Placeholder - would need separate implementation
            "recent_news": [],  # Placeholder - would need separate implementation
            # Enhanced Indicators
            "pro_indicators": {
                "macd": {
                    "line": round(macd_line.iloc[-1], 6),
                    "signal": round(signal_line.iloc[-1], 6),
                    "hist": round(macd_hist.iloc[-1], 6)
                },
                "bollinger": {
                    "upper": round(bb_upper.iloc[-1], 6),
                    "lower": round(bb_lower.iloc[-1], 6),
                    "bandwidth": round(bb_bandwidth.iloc[-1], 4)
                },
                "atr": round(atr_val, 6),
                "ema_trend": ema_trend,
                "price_pos": price_pos,
                "ema_values": {
                    "ema7": round(ema7, 6),
                    "ema25": round(ema25, 6),
                    "ema99": round(ema99, 6)
                }
            },
            # Legacy Support
            "legacy": {
                "above_all_emas": above_all_emas_legacy,
                "consecutive_bullish": consecutive_bullish,
                "strategy_match": strategy_match
            }
        }
    
    def get_strong_coins(self, min_rsi: float = 50, max_rsi: float = 70, min_change_24h: float = 2.0) -> List[Dict]:
        """
        Step 4: Analyze all contracts and return strong coin recommendations
        """
        print("Fetching all USDT perpetual futures...")
        symbols = self.get_exchange_info()
        print(f"Found {len(symbols)} USDT perpetual futures")
        
        strong_coins = []
        
        for i, symbol in enumerate(symbols):
            print(f"Analyzing {symbol} ({i+1}/{len(symbols)})...")
            
            try:
                df = self.get_kline_data(symbol, "15m", 100)
                if df.empty:
                    continue
                    
                analysis = self.analyze_technical_indicators(df, symbol)
                
                if not analysis:
                    continue
                
                # Determine if it's a strong coin based on multiple criteria
                is_strong = (
                    analysis["change_percent_24h"] >= min_change_24h and
                    min_rsi <= analysis["rsi"] <= max_rsi and
                    analysis["pro_indicators"]["ema_trend"] in ["强多头 (Bullish)", "震荡"] and
                    analysis["pro_indicators"]["price_pos"] == "站上所有均线 (Strong)" and
                    analysis["volume_status"] in ["放量", "正常"]
                )
                
                if is_strong or analysis["legacy"]["strategy_match"]:
                    strong_coins.append(analysis)
                    
            except Exception as e:
                print(f"Error analyzing {symbol}: {e}")
                continue
        
        # Sort by 24h change percentage
        strong_coins.sort(key=lambda x: x["change_percent_24h"], reverse=True)
        
        return strong_coins
    
    def print_analysis_report(self, analysis: Dict):
        """
        Print formatted analysis report for a single coin
        """
        print(f"\n=== {analysis['symbol']} Analysis ===")
        print(f"Price: {analysis['price']}")
        print(f"24h Change: {analysis['change_percent_24h']}%")
        print(f"Period Change: {analysis['change_percent_period']}%")
        print(f"Volume Status: {analysis['volume_status']}")
        print(f"Day Quote Volume: {analysis['day_quote_volume_m']}M")
        print(f"Volatility: {analysis['volatility']}")
        print(f"RSI: {analysis['rsi']}")
        print(f"High Distance: {analysis['high_distance_pct']}%")
        print(f"Trend: {analysis['pro_indicators']['ema_trend']}")
        print(f"Position: {analysis['pro_indicators']['price_pos']}")
        print(f"EMAs: EMA7={analysis['pro_indicators']['ema_values']['ema7']}, "
              f"EMA25={analysis['pro_indicators']['ema_values']['ema25']}, "
              f"EMA99={analysis['pro_indicators']['ema_values']['ema99']}")
        print(f"MACD: Line={analysis['pro_indicators']['macd']['line']}, "
              f"Signal={analysis['pro_indicators']['macd']['signal']}, "
              f"Histogram={analysis['pro_indicators']['macd']['hist']}")
        print(f"Bollinger: Upper={analysis['pro_indicators']['bollinger']['upper']}, "
              f"Lower={analysis['pro_indicators']['bollinger']['lower']}, "
              f"Bandwidth={analysis['pro_indicators']['bollinger']['bandwidth']}")
        print(f"ATR: {analysis['pro_indicators']['atr']}")
        print(f"Legacy Strategy Match: {analysis['legacy']['strategy_match']}")


def main():
    """
    Example usage
    """
    analyzer = CryptoContractAnalyzer()
    
    print("Starting crypto contract analysis...")
    strong_coins = analyzer.get_strong_coins()
    
    print(f"\nFound {len(strong_coins)} potentially strong coins:")
    for coin in strong_coins:
        analyzer.print_analysis_report(coin)
        print()


if __name__ == "__main__":
    main()