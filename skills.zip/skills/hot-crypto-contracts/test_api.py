import requests

# 测试正确的币安API端点
def test_binance_api():
    # 尝试不同的端点
    endpoints = [
        "https://api.binance.com/api/v3/exchangeInfo",
        "https://fapi.binance.com/fapi/v1/exchangeInfo",
        "https://dapi.binance.com/dapi/v1/exchangeInfo"
    ]
    
    for endpoint in endpoints:
        try:
            print(f"Testing {endpoint}")
            response = requests.get(endpoint, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if 'symbols' in data:
                    usdt_symbols = [s['symbol'] for s in data['symbols'][:5] if 'USDT' in s['symbol']]
                    print(f"  Success! Found {len(data.get('symbols', []))} symbols, sample: {usdt_symbols}")
                    break
                else:
                    print(f"  Got 200 but unexpected structure: {list(data.keys())}")
            else:
                print(f"  Status: {response.status_code}")
        except Exception as e:
            print(f"  Error: {e}")

test_binance_api()