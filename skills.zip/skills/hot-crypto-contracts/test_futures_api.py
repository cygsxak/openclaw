import requests

# 测试币安期货API
def test_futures_api():
    endpoint = "https://fapi.binance.com/fapi/v1/exchangeInfo"
    
    try:
        print(f"Testing {endpoint}")
        response = requests.get(endpoint, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if 'symbols' in data:
                # Filter for USDT perpetual futures
                usdt_symbols = [
                    s['symbol'] 
                    for s in data['symbols'] 
                    if s['quoteAsset'] == 'USDT' and s['contractType'] == 'PERPETUAL'
                ][:10]  # Show first 10
                print(f"  Success! Found {len(usdt_symbols)} USDT perpetual symbols, sample: {usdt_symbols}")
                
                # Test getting K-lines for BTCUSDT
                kline_endpoint = "https://fapi.binance.com/fapi/v1/klines"
                kline_params = {
                    'symbol': 'BTCUSDT',
                    'interval': '15m',
                    'limit': 10
                }
                kline_response = requests.get(kline_endpoint, params=kline_params, timeout=10)
                if kline_response.status_code == 200:
                    kline_data = kline_response.json()
                    print(f"  K-line test successful! Got {len(kline_data)} candles for BTCUSDT")
                    print(f"  Sample candle: {kline_data[0] if kline_data else 'None'}")
                else:
                    print(f"  K-line test failed with status: {kline_response.status_code}")
            else:
                print(f"  Got 200 but unexpected structure: {list(data.keys())}")
        else:
            print(f"  Status: {response.status_code}")
            print(f"  Response: {response.text[:200]}")
    except Exception as e:
        print(f"  Error: {e}")

test_futures_api()