# Hot Crypto Contracts Skill

## Description
This skill analyzes hot virtual currency contracts on Binance, providing technical indicators and trading signals based on market data.

## Features
- Fetches contract information from Binance API
- Retrieves 15-minute K-line data
- Analyzes multiple technical indicators
- Provides strong coin recommendations

## Technical Indicators
- EMAs (7, 25, 99) for trend analysis
- RSI (14) for momentum
- MACD (12, 26, 9) for trend direction
- Bollinger Bands (20, 2) for volatility
- ATR (14) for average true range
- Volatility metrics
- Volume analysis

## API Endpoints Used
- `/fapi/v1/exchangeInfo` - Get contract information
- `/fapi/v1/klines` - Get K-line data
- `/fapi/v1/ticker/24hr` - Get 24-hour ticker data

## Response Format
Returns detailed analysis including:
- Symbol and current price
- Price change percentages
- Volume status
- Technical indicators values
- Trend analysis
- Legacy strong coin logic support