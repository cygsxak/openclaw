# 虚拟币合约交易信号分析技能

## 概述
这个技能可以分析币安上的USDT永续合约，提供详细的技术指标分析和强势币种推荐。该技能实现了您要求的四个步骤：

1. 通过币安接口获取合约信息
2. 获取15分钟K线数据
3. 分析多种技术指标（EMA、RSI、MACD、布林带等）
4. 识别强势品种并生成清单

## 功能特性

### 技术指标分析
- **EMA趋势分析**: 使用EMA7、EMA25、EMA99判断趋势方向
- **RSI指标**: 14周期相对强弱指数
- **MACD指标**: 12、26、9参数的指数平滑异同移动平均线
- **布林带**: 20周期、2倍标准差的布林带分析
- **ATR指标**: 14周期平均真实波幅
- **波动率分析**: 基于收益率的标准差计算
- **成交量分析**: 与历史平均成交量对比分析
- **传统强势币逻辑**: 基于EMA3、EMA9、EMA120的强势币判断

### 优势
- 实时获取最新市场数据
- 多维度技术指标综合分析
- 智能识别强势品种
- 提供交易建议参考

## 安装依赖
在使用此技能前，请确保安装了必要的Python包：
```bash
pip install pandas requests numpy
```

## 使用方法

### 1. 基本使用
```python
from skills.hot_crypto_contracts.crypto_contract_analyzer import CryptoContractAnalyzer

analyzer = CryptoContractAnalyzer()

# 获取所有强势币种
strong_coins = analyzer.get_strong_coins()

# 打印分析报告
for coin in strong_coins:
    analyzer.print_analysis_report(coin)
```

### 2. 单个合约分析
```python
# 获取特定合约的K线数据
df = analyzer.get_kline_data("BTCUSDT")

# 分析技术指标
analysis = analyzer.analyze_technical_indicators(df, "BTCUSDT")
print(analysis)
```

## 分析指标

### 趋势指标
- **EMA趋势**: 使用EMA7、EMA25、EMA99判断趋势方向
- **价格位置**: 判断当前价格相对于各均线的位置

### 动量指标
- **RSI (14)**: 相对强弱指数
- **MACD (12, 26, 9)**: 指数平滑异同移动平均线

### 波动率指标
- **布林带 (20, 2)**: 显示价格波动范围
- **ATR (14)**: 平均真实波幅
- **波动率**: 收益率标准差

### 成交量指标
- **成交量状态**: 与平均成交量比较判断是否放量或缩量
- **24小时成交额**: 衡量市场活跃度

### 传统强势币逻辑
- 价格高于EMA3、EMA9、EMA120
- 连续三个K线看涨
- 价格距离100周期最高点超过10%

## 输出格式
分析结果包含以下字段：
- symbol: 合约代码
- price: 当前价格
- change_percent_24h: 24小时价格变化百分比
- rsi: RSI指标值
- ema_trend: EMA趋势判断
- volume_status: 成交量状态
- pro_indicators: 专业指标详细数据
- legacy: 传统强势币逻辑结果

## 筛选参数
`get_strong_coins()` 方法接受以下参数：
- min_rsi: 最小RSI阈值（默认50）
- max_rsi: 最大RSI阈值（默认70）
- min_change_24h: 24小时最小涨幅（默认2.0%）